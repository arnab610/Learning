package com.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.entity.AdminFeedback;
@Repository
public interface AdminFbRepository extends JpaRepository<AdminFeedback, Long>{

}

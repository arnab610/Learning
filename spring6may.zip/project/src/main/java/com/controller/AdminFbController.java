package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Admin;
import com.entity.AdminFeedback;
import com.exception.AdminAlreadyExistsException;
import com.exception.AdminNotFoundException;
import com.repository.AdminFbRepository;
import com.repository.AdminRepository;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin("*")
public class AdminFbController {
	@Autowired
	private AdminFbRepository afr;
	
	@PostMapping("/adminfeedback")
	public AdminFeedback saveAdmin(@RequestBody AdminFeedback admin) {
		return afr.save(admin);
	}
	
	@GetMapping("/adminfeedbacks")
	public List<AdminFeedback > getAllAdmin() {
		return afr.findAll();
	}
	
	@GetMapping("/adminfeedback/{id}")
	public AdminFeedback  getAdminById(@PathVariable Long id) {
		return afr.findById(id).get();
	}
}

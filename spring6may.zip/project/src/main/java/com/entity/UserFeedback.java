package com.entity;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "userfeedbacks")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserFeedback {
	public UserFeedback() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "UserFeedback [id=" + id + ", userName=" + userName + ", feedback=" + feedback + ", movie=" + movie
				+ ", noofStars=" + noofStars + "]";
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public String getMovie() {
		return movie;
	}
	public void setMovie(String movie) {
		this.movie = movie;
	}
	public int getNoofStars() {
		return noofStars;
	}
	public void setNoofStars(int noofStars) {
		this.noofStars = noofStars;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private long id;
	private String userName;
	private String feedback;
	private String movie;
	private int noofStars;
	
	
	
}

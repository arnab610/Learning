var express = require('express')
var bp = require('body-parser')
var app=express()
app.use(bp.json())

var project=[
    
]
uid=1

app.get('/loadproject', (req, res)=>{
    res.json(project)
    //res.send(users)
})
app.post('/addproject', (req,res)=>{
    var data = req.body
    data.projectid=uid++
    project.push(data)
    res.send('project is added '+data)
})

app.get('/loadproject/:id', (req, res)=>{
    var lid= parseInt(req.params.id)
   //console.log(lid)
   var mtd
   project.forEach(function(td){
       if(lid== td.projectid){
           mtd=td
       }
   })
   if(mtd){
       res.json(mtd)
   }
   else{
       res.status(404).send()
   }
})
app.listen(3000, ()=>{
    console.log('server is ready');
})
var express = require('express')
var bp = require('body-parser')
var app=express()
app.use(bp.json())
uid=1

var dept=[
    
]
app.use(express.static('public'))
app.get('/loaddepartments', (req, res)=>{
    res.json(dept)
    //res.send(users)
})
app.post('/adddept', (req,res)=>{
    var data = req.body
    data.id=uid++
    dept.push(data)
    res.send('dept is added '+data)
})
app.get('/loaddepartments/:id', (req, res)=>{
    var lid= parseInt(req.params.id)
    //console.log(lid)
    var mtd
    dept.forEach(function(td){
        if(lid== td.id){
            mtd=td
        }
    })
    if(mtd){
        res.json(mtd)
    }
    else{
        res.status(404).send()
    }
 })
app.listen(5000, ()=>{
    console.log('server is ready');
})
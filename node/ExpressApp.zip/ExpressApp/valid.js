function validateform(){  
   
    var name=document.myform.uname.value;  
     
    var email=document.myform.email.value;  
    var city=document.myform.city.value;  


    if (name==null || name==""){  
      alert("Name can't be blank");  
      return false;  
    }
      else if(email==null || email==""){  
        alert("Email can't be blank"); 
        return false;  
      }
      else if(city==null || city==""){  
        alert("city can't be blank"); 
        return false; 
      }
      return true
      console.log("helo")
    }
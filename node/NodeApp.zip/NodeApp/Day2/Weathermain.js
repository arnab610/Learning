

var weather = require('./Weatherapp.js')
var l = require('./location.js')
var argv= require('yargs')
.option('loc', {
    type:'string'
}).help('help')
.argv

weather(argv.loc,function(callback){
    console.log(callback);
})
l((callback)=>{
    console.log(callback);
})
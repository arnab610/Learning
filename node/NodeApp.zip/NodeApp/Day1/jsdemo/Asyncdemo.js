const getblogs=()=>{
    setTimeout(()=>{
        return{
            uname:'admin'
        }
    },2000);
}
const bp = getblogs()
console.log(bp.uname);
const getblogs=(cbapp)=>{
    setTimeout(()=>{
        cbapp({
            uname:'admin'
        })
        
    },2000);
}
 getblogs((bp)=>{
    console.log(bp.uname);
 })

function getUser(id,cb){
    setTimeout(() => {
        console.log('Getting the users from social media platforms');
        cb({
            id:id,
            name:'Arnab'
        })
    }, 1000);
}

function getBlogs(username,cb){
    setTimeout(() => {
        console.log('calling the rest apis to load the posts');
        cb(['Post-1','Post-2','Post-3']
           
        )
    }, 1000);
}

function loadComments(post,cb){
    setTimeout(() => {
        console.log('Getting the users from all the comments');
        cb(['Comments for '+post]
            
        )
    }, 1000);
}

getUser(101,(user)=>{
    getBlogs(user.name,(blogs)=>{
        
            for(var i=0;i<blogs.length;i++){
                loadComments(blogs[i],(comments)=>{
                    console.log(blogs);
                    console.log(user,blogs[i],comments);
        })

        }
    })
})
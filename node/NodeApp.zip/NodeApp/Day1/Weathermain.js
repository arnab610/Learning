var weather = require('./Weatherapp.js')
weather(function(callback){
    console.log(callback)
})
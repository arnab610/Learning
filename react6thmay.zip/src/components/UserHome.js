import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import AdminService from '../services/employee.service';
import { useHistory } from "react-router-dom";
import dateFormat from 'dateformat';

const UserHome = () => {
    const [movies, setMovies] = useState([]);
    const history = useHistory();
    const [silver, setSilver] = useState(0);
    const [gold, setGold] = useState(0);
    const [Platinum, setPlatinum] = useState(0);
    const [name, setName] = useState('')
    const [multiplex, setMultiplex] = useState('');

    const init = () => {
      AdminService.getAllMovies()
        .then(response => {
          console.log('Printing Movies data', response.data);
          setMovies(response.data);
        })
        .catch(error => {
          console.log('Something went wrong', error);
        }) 
    }
  
    useEffect(() => {
      init();
    }, []);

    const booking = (m) => {
        const {id, movName, description, multiplex, img, date, time, silverSeat, goldSeat, platinumSeat, discount, price} = m
        var p1 = 0;
        var p2 = 0;
        var p3 = 0;
        if(silver !== 0) {
            p1 = price * parseInt(silver);
        }
        if(gold !== 0) {
            p2 = (price  + 40)* parseInt(gold);
        }
        if(Platinum !== 0) {
            p3 = (price + 80 )* parseInt(Platinum);
        }
        var totPrice = (p1 + p2 + p3) - (p1 + p2 + p3) * (parseInt(discount) / 100);
        var head = parseInt(silver) + parseInt(gold) + parseInt(Platinum);
        const cart = {userId: id, movieName: movName,multiplex:multiplex,discount:parseInt(discount),img:img, price: totPrice,noofHeads: head,dt: date};
        console.log(cart)
        var updatedSilverSeat = silverSeat - parseInt(silver);
        var updatedGoldSeat = goldSeat - parseInt(gold);
        var updatedPlatinumSeat = platinumSeat - parseInt(Platinum);
        var updatedMov;
        updatedMov = {id, movName, description, multiplex, img, date, time, silverSeat: updatedSilverSeat, goldSeat: updatedGoldSeat, platinumSeat: updatedPlatinumSeat, discount, price}
        console.log(updatedMov)
        AdminService.updateMovie(updatedMov)
            .then(response => {
                console.log('movie data updated successfully', response.data);
            })
            .catch(error => {
                console.log('Something went wrong', error);
            })
        AdminService.createCart(cart)
            .then(response => {
                console.log("movie added successfully", response.data);
                history.push("/cart");
            })
            .catch(error => {
                console.log('something went wrong', error);
            }) 
    }

    return (
        <div className="container">
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
       <div class="container-fluid">
       <Link to="/user" className="btn btn-primary mb-2 mx-4">Home</Link>
         <div class="collapse navbar-collapse" id="navbarNavDropdown">
           <ul class="navbar-nav">

             <li class="nav-item">
             <Link className="btn btn-primary mb-2 mx-4" to="/cart">Cart</Link>
             </li>

             <li class="nav-item">
             <input type="text" placeholder="Search Multiplex" className="form-control" name="names" onChange={(e) => setName(e.target.value)} />
             </li>
           </ul>
         </div>
       </div>
     </nav>
     
            <div className="row">
            {movies.filter((n) => {
                if(name == "") {
                    return n;
                } else if(n.multiplex.toLowerCase().includes(name.toLowerCase())) {
                    return n;
                }
            }).map((m, key) => {
                return (
                (  m.silverSeat === 0 && m.goldSeat === 0 && m.platinumSeat === 0)? null : 
                (<div className="col-lg-6 mb-4">
				<div className="card">
					<img className="card-img-top " style={{width: "538px", height: "400px"}} src={m.img} alt=""/>

					<div className="card-body">
						<h5 className="card-title">{m.movName}</h5>
						<p className="card-text">{m.description}</p>
                        <p className="card-text">{m.multiplex}</p>
                        <p className="card-text">{dateFormat(m.dateFormat, 'mm/dd/yyyy')}</p>
                        <p className="card-text"><b>DISCOUNT : </b>{m.discount} %</p>
                        <table className="table table-bordered w-80">
 
                <tbody>
                    <tr>
                        <td>Silver</td>
                        <td>Rs. {m.price}</td>
                        <td><input type="number" className="w-25" id="silver" min="1" max={m.silverSeat} onChange={(e) => setSilver(e.target.value)}/> Seats</td>
                        <td>{m.silverSeat}</td>
                    </tr>
        
                    <tr>
                        <td>Gold</td>
                        <td>Rs.{m.price + 40}</td>
                        <td><input type="number" className="w-25" min="1" max={m.goldSeat} onChange={(e) => setGold(e.target.value)}/> Seats</td>
                        <td>{m.goldSeat}</td>
                    </tr>
        
                    <tr>
                        <td>Platinum</td>
                        <td>Rs.{m.price + 80}</td>
                        <td><input type="number" className="w-25" min="1" max={m.platinumSeat} onChange={(e) => setPlatinum(e.target.value)}/> Seats</td>
                        <td>{m.platinumSeat}</td>
                    </tr>
                </tbody>
    </table>
                        <button type="button" onClick={() => booking(m)} disabled={(silver === 0 && gold === 0 && Platinum === 0)} className="btn btn-primary mx-2">BOOK</button>
                        <Link to={`/userfeedback/${m.movName}`} className="btn btn-primary">FEEDBACK</Link>
					</div>
				</div>
			</div>))
})}
            </div>
        </div>
      );
}

export default UserHome;
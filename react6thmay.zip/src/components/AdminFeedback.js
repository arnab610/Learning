import { useState } from "react";
import { useHistory, Link } from "react-router-dom";
import AdminFeedbackService from "../services/AdminFeedbackService";

const Adminfeedback = () => {
    const [adminname, setAdminname] = useState('')
    const [feedback, setFeedback] = useState('Good');
    const history = useHistory();
    const submitFeedback =(e) => {
        e.preventDefault()
        var feed = {adminName: adminname, feedback: feedback}
        console.log(feed)
        AdminFeedbackService.create(feed)
        .then(response => {
            alert('Thank You For Feedback')
            console.log("Feedback ", response.data);
            history.push("/admin");
        })
        .catch(error => {
            console.log('something went wroing', error);
        })
    }
    return (
        <div>
            <div class="card" style={{width:"18rem"}}>
                <div class="card-body">
                        <h5 class="card-title">Your Feedback</h5>
                        <hr></hr>
                        <Link to="/admin">Back to Home</Link>
                        <hr></hr>
                        <form>
                        <div class="mb-3">
                            <label for="username" class="form-label">Admin Name</label>
                            <input 
                                type="text" 
                                class="form-control" 
                                id="adminname" 
                                value={adminname}
                                onChange={(e) => setAdminname(e.target.value)}
                                />
                        </div>
                        <div class="mb-3 ">
                            <label for="floatingTextarea">Feedback</label>
                            <textarea 
                                class="form-control" 
                                placeholder="Leave a comment here" 
                                id="floatingTextarea"
                                value={feedback}
                                onChange={(e) => setFeedback(e.target.value)}
                                />
                        </div>
                        <button type="submit" onClick={(e) => submitFeedback(e)} class="btn btn-primary">Submit</button>
                        </form>
                </div>
            </div>
            
        </div>
    );
}

export default Adminfeedback;
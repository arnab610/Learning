import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import AdminService from '../services/employee.service';
import { useHistory } from "react-router-dom";
import dateFormat from 'dateformat';

const Cart = () => {
    const [cart, setCart] = useState([]);
    const init = () => {
        AdminService.getAllCarts()
          .then(response => {
            console.log('Printing Movies data', response.data);
            setCart(response.data);
          })
          .catch(error => {
            console.log('Something went wrong', error);
          }) 
      }
    
      useEffect(() => {
        init();
      }, []);
    return (
        <div className="container">
          <h3>Your Cart</h3>
          <hr></hr>
          <Link to="/user">Back to Home</Link>
          <hr/>
            <div className="row">
            {cart.map((m) => (
                <div className="col-lg-6 mb-4">
				<div className="card">

					<div className="card-body">
						<h5 className="card-title">{m.movieName}</h5>
						
                        <p className="card-text">{m.multiplex}</p>
                        <p className="card-text">{dateFormat(m.dateFormat, 'mm/dd/yyyy')}</p>
                        <p className="card-text"><b>DISCOUNT : </b>{m.discount} %</p>
                        <p className="card-text"><b>{m.noofHeads}</b>Tickets</p>

                  
				</div>
			</div>
            </div>
            ))}
            </div>
        </div>
      );
}

export default Cart;
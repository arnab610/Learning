import FeedbackService from "../services/FeedbackService";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import AdminFeedbackService from "../services/AdminFeedbackService";

const Adminfeedbackdisplay = () => {
    const [adminFeedback, setAdminFeedback] = useState([]);

    const init = () => {
      AdminFeedbackService.getAll()
        .then(response => {
          console.log('Printing Movies data', response.data);
          setAdminFeedback(response.data);
        })
        .catch(error => {
          console.log('Something went wrong', error);
        }) 
    }
  
    useEffect(() => {
      init();
    }, []);
    return (
        <div className="container">
          <h3>List of Admin Feedbacks</h3>
          <hr></hr>
          <Link to="/">Back to Home</Link>
          <hr/>
          <div>
            <table className="table table-bordered table-striped">
              <thead className="thead-dark">
                <tr>
                  <th>Name</th>
                  <th>Feedback</th>

                </tr>
              </thead>
              <tbody>
              {
                adminFeedback.map(f => (
                
                  <tr key={f.id}>
                      <td>{f.adminName}</td>
                    <td>{f.feedback}</td>
                  </tr>
                ))
              }
              </tbody>
            </table>
            
          </div>
        </div>

      );
}

export default Adminfeedbackdisplay;
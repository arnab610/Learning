import { BrowserRouter, Switch, Route } from 'react-router-dom';
import NotFound from './components/NotFound';
import 'bootstrap/dist/css/bootstrap.min.css';
import AdminHome from './components/AdminHome';
import AddMovies from './components/AddMovies';
import AddAdmin from './components/AddAdmin';
import UserHome from './components/UserHome';
import Cart from './components/Cart';
import Userfeedback from './components/UserFeedback';
import Adminfeedback from './components/AdminFeedback';
import ApplicationManager from './components/ApplicationManager';
import userfeedbackdisplay from './components/UserFeedbackDisplay';
import Adminfeedbackdisplay from './components/AdminFeedbackDisplay';

function App() {
  return (
    <BrowserRouter>
      <div>
        <div>
          <Switch>
          
            <Route path="/"  exact component={ApplicationManager} />
            <Route exact path="/addadmins" component={AddAdmin} />
            <Route path="/admin" component={AdminHome} />
            <Route path="/add" component={AddMovies} />
            <Route path="/user" component={UserHome} />
            <Route path="/cart" component={Cart} />
            <Route path="/userfeedback/:name" component={Userfeedback} />
            <Route path="/adminfeedback" component={Adminfeedback} />
            <Route path="/movies/edit/:id" component={AddMovies} />
            <Route path="/userfeedbackdisplay" component={userfeedbackdisplay} />
            <Route path="/adminfeedbackdisplay" component={Adminfeedbackdisplay} />
            
            <Route path="*" component={NotFound} />
          </Switch>
        </div>
      </div>
    </BrowserRouter>
  );
}


export default App;

package com.testapp;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CalculatorTest {
	
	@BeforeEach
	public void beforecall() {
		System.out.println("Calling before");
	}

	@Test
	void testAdd() {
		//fail("Not yet implemented");
		assertEquals(25, new Calculator().add(13, 12));
	}

}

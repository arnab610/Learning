package com.examples.framework.data;

public class FooterSectionData {
	// Report Date, Page #
	public String footerMSG = "";
}

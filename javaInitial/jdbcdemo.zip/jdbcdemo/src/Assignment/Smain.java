package Assignment;

public class Smain {
public static void main(String[] args) {
	String res= args[0];
	if(res.equals("hostellite")){
		Student ob = new Student("hostel", "Ankit");
		System.out.println(ob.getName());
		System.out.println(ob.fees(12));
		System.out.println(ob.fees(13,14));
	}
}
}

package Assignment;

public class Student {
private String res;
private String Name;
public String getRes() {
	return res;
}
public void setRes(String res) {
	this.res = res;
}
public String getName() {
	return Name;
}
public void setName(String name) {
	Name = name;
}
public Student(String res, String name) {
	super();
	this.res = res;
	Name = name;
}
public double fees(double a) {
	return a;
}
public double fees(double a, double b) {
	return a+b;
}

}

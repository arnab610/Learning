package Assignment;

public class Assignment6 {
public static void main(String[] args) {
	int no,iteration;
	//no = Integer.parseInt(args[0]);
	//i/teration= Integer.parseInt(args[1]);
	//for(int i=1; i<=iteration; i++)
		//System.out.println(i*no);
	//String s="Arnab";
	//System.out.println(s.replace("Arnab","Panda"));
}
}

package com.stud;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.jdbcdemo.Emloyee;

public class Get {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//ArrayList<Emloyee> al = new ArrayList<>();
		String query ="Select * from students";
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn =DriverManager.getConnection("jdbc:mysql://localhost:3306/pwcdb", "root", "root123");
		PreparedStatement pst = conn.prepareStatement(query);
		ResultSet rs = pst.executeQuery();
		while(rs.next()) {
			int roll= rs.getInt(1);
			String name= rs.getString(2);
			String city= rs.getString(3);
			String sub= rs.getString(4);
			System.out.println(name+" "+roll+" "+ city+" "+ sub);
			
		}
		
}
}


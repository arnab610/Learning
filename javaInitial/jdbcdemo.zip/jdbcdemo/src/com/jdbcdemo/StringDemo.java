package com.jdbcdemo;

public class StringDemo {
public static void main(String[] args) {
	String s= "Arnab";
	String s1 = new String("Arnab");String s5 = new String("Arnab");
	System.out.println(s1==s5);
	String s3=s1;
	String s4= "Arnab";
	System.out.println(s.equals(s1));
	System.out.println(s==s1);
	System.out.println(s3==s1);
	System.out.println(s==s4);
}
}

package day4asg;

public class Hostellite extends Student {
private String hostelname;
private int roomno;
public Hostellite(int id, String fname, char t, String lname, String hostelname, int roomno) {
	super(id, fname, t, lname);
	this.hostelname = hostelname;
	this.roomno = roomno;
}
public Hostellite() {
	
}
@Override
public void details() {
	System.out.println(hostelname+ " "+id);
	super.details();
}
public static void main(String[] args) {
	Student ob = new Hostellite(101, "Ankit", 'H', "Nath", "Rhr", 22);
	ob.setFees(13);
	//System.out.println(ob.hostelname+ ob.getId()+ ob.id);
	ob.details();
}


}

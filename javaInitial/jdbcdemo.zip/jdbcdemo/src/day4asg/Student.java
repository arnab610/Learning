package day4asg;

public class Student {
protected int id;
private String name;
private char t;
private double fees;
public Student(int id, String fname, char t, String lname) {
	super();
	this.id = id;
	this.name = fname+lname;
	this.t = t;
	
}
public void details() {
	System.out.println("gh"+name);
}

public Student() {
	super();
}

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public char getT() {
	return t;
}
public void setT(char t) {
	this.t = t;
}
public double getFees() {
	return fees;
}
public void setFees(double fees) {
	this.fees = fees;
}

}

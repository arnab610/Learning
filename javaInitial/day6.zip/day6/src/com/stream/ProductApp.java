package com.stream;

import java.util.ArrayList;
import java.util.List;

public class ProductApp {
public static void main(String[] args) {
	List<Products> al = new ArrayList<Products>();
	al.add(new Products(101, "Ram", 2001));
	al.add(new Products(105, "Shyam", 200));
	al.add(new Products(103, "Babu", 2100));
	al.add(new Products(100, "Hari", 1200));
	al.add(new Products(110, "Om", 3000));
	al.stream().filter((s)-> s.getPrice()>2000).forEach(System.out::println);
}
}

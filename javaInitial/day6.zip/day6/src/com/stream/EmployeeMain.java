package com.stream;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class EmployeeMain {
public static void main(String[] args) {
	List<Employee> al = new ArrayList<Employee>();
	al.add(new Employee(100, 4000, "Uzui", "IT"));
	al.add(new Employee(105, 4001, "Sasuke", "CS"));
	al.add(new Employee(103, 5000, "Tengen", "Civi"));
	al.add(new Employee(110, 4001, "Kakashi", "Mech"));
	al.add(new Employee(99, 5000, "Naruto", "IT"));
	List<String> l1= al.stream().filter((s)-> s.getInc()>4000).map(s->s.getName().toUpperCase()).collect(Collectors.toList());
	System.out.println(l1);
	long d=al.stream().filter((s)-> s.getDept().equals("IT")).count();
	System.out.println(d);
	//List<Employee> l2= al.stream().sorted().collect(Collectors.toList());
	//System.out.println(l2);
	Optional<Employee> emp = al.stream().collect(Collectors.maxBy(Comparator.comparing(Employee::getInc)));
	System.out.println(emp);
	
	Optional<Employee> emp2 = al.stream().collect(Collectors.minBy(Comparator.comparingInt(Employee::getInc)));
	System.out.println(emp2);
}
}


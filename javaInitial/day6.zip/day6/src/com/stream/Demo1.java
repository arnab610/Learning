package com.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Demo1 {
public static void main(String[] args) {
	List<String> l = new ArrayList<String>();
	l.add("administrator");
	l.add("admin");
	
	l.add("manager");
	l.add("tester");
	l.stream().filter((s)-> s.startsWith("a")).forEach(System.out::println);
	l.stream().filter((s)-> s.startsWith("a")).map(String::toUpperCase).forEach(System.out::println);
	l.stream().sorted().filter((s)-> s.startsWith("a")).map(String::toUpperCase).forEach(System.out::println);
	List<String> l1= l.stream().sorted().filter((s)-> s.startsWith("a")).map(String::toUpperCase).collect(Collectors.toList());
	System.out.println(l1);
	long d=l.stream().sorted().filter((s)-> s.startsWith("a")).count();
	System.out.println(d);
}
}
package com.sam;

public class WorkerApp{

	public static void execute(Worker w) {
		w.doSomeWork();
	}
	public static void main(String[] args) {
		execute(new Worker() {
			
			@Override
			public void doSomeWork() {
				// TODO Auto-generated method stub
				System.out.println("Doing something");
			}
		});
	
	execute(()->System.out.println("Doing"));
	Worker ob =()-> System.out.println("moshi");
	execute(ob);
	}
}

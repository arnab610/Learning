package com.sam;

public class TaskImpl implements Task1, Task2 {


	//@Override
	//public void showUpdate() {
		// TODO Auto-generated method stub
		//Task1.super.showUpdate();
	//}

	@Override
	public void showApp() {
		// TODO Auto-generated method stub
		System.out.println("Show app called");
	}
	//@Override
	///public void showUpdate() {
		// TODO Auto-generated method stub
		//Task2.super.showUpdate();
	//}
	public static void main(String[] args) {
		Task1 i = new TaskImpl();
		i.showApp();
		//i.showUpdate();
		Task2 i1 = new TaskImpl();
		i1.showApp();
		i1.showUpdate();
	}

}

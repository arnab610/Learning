package com.sam;

public class Defaultimpl implements DefaultDemo {

	@Override
	public void add() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		
	}

}

package com.sam;
@FunctionalInterface
public interface Task2 {
	public void showApp();
	public default void showUpdate() {
		System.out.println("hello task2");
	}
}

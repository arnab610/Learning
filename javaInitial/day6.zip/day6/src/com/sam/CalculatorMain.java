package com.sam;

public class CalculatorMain {
public static void exec(Calculator c, int a, int b) {
		c.add(a,b);
	}
public static void main(String[] args) {
	Calculator ob = (int a,int b)-> System.out.println(a+b);
	//System.out.println(ob.add(10, 20));
	exec(ob, 20,30);
}
}

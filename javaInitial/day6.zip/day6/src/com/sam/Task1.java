package com.sam;
@FunctionalInterface
public interface Task1 {
public void showApp();
//public default void showUpdate() {
	//System.out.println("hello task1");
//}
}

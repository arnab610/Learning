package com.sam;
@FunctionalInterface
public interface Worker {
public void doSomeWork();
//public void ss(int i);
}

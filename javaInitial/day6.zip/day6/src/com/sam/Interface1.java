package com.sam;
@FunctionalInterface
public interface Interface1 {
public void add();
//public void show();
}

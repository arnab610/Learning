package com.sam;

public interface Calculator {
	public void add(int a, int b);

}

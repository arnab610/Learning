package com.sam;

import java.util.ArrayList;
import java.util.Collections;



public class ArrayListDemo {
	public static void main(String[] args) {
		ArrayList<User> al = new ArrayList<>();
		al.add(new User(12, "Tengen", "flashy@gmil.com"));
		al.add(new User(13, "Tang", "ashy@gmil.com"));
		al.add(new User(14, "Aeng", "shy@gmil.com"));
		//System.out.println(al);
		Collections.sort(al, (User u1, User u2)-> u1.getUserName().compareTo(u2.getUserName()));
		for(User us:al) {
			System.out.println(us);
		}
		
		//System.out.println(al.get(2));
		//al.remove(0);
		//for(User us:al) {
			//System.out.println("\n Second time"+ us);
		//}//
	}

}

package OptionalDemo;

import java.util.Optional;

public class OptDemo {
public static void main(String[] args) {
	Optional<String> opt = Optional.ofNullable(null);
	if(opt.isPresent()) {
		System.out.println("Available");
		
	}
	else {
		opt.ifPresent(s-> System.out.println(s.length()));
	}
}
}

package OptionalDemo;

public class User {
	Address address;
Address getaddr() {
	return this.address;
}

public User(Address address) {
	super();
	this.address = address;
}

public static void main(String[] args) {
	User user = new User(new Address("India"));
	if(user != null) {
		Address add = user.getaddr();
		if(add!= null && add.getCountry().equalsIgnoreCase("India"));{
			System.out.println("User belongs to India");
		}
		
	}
//	userOptional.map(User::getAddress)
//	.filter(address -> address.getCountry().equalsIgnoreCase("India"))
//	.ifPresent(() -> {
//	    System.out.println("User belongs to India");
//	});
}
}

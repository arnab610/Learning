package com.client;


import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.entity.Employee;
import com.entity.Student;
import com.hibernate.HibernateUtility;


public class NewClient {
public static void main(String[] args) {
	Session session = HibernateUtility.getSession();
	Transaction tx = session.beginTransaction();
	Student em = new Student(14, "CS", 92);
	
	
	session.save(em);
	tx.commit();
	System.out.println("User added");

}
}

package com.client;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;


import com.entity.Student;
import com.hibernate.HibernateUtility;

public class LoadStudent {
	public static void main(String[] args) {
		Session session = HibernateUtility.getSession();
		Query query =(Query) session.createQuery("from Student");
		List<Student> lst = query.list();
		for(Student em: lst) {
			System.out.println(em);
		}
	}

}

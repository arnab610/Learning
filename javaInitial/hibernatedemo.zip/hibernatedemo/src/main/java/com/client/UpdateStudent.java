package com.client;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.entity.Employee;
import com.entity.Student;
import com.hibernate.HibernateUtility;

public class UpdateStudent {
public static void main(String[] args) {
	Session session = HibernateUtility.getSession();
	Transaction tx = session.beginTransaction();
	Student em =(Student)session.get(Student.class, 14);
	em.setSubject("IT");
	session.update(em);
	tx.commit();
	System.out.println("User updated");
}
}

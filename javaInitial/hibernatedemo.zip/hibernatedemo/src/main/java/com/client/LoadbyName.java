package com.client;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;

import com.entity.Employee;
import com.hibernate.HibernateUtility;

public class LoadbyName {
public static void main(String[] args) {
	Session session = HibernateUtility.getSession();
	Query query =(Query) session.createQuery("from Employee where city=:name");
	query.setParameter("name", "Bombay");
	List<Employee> lst = query.list();
	for(Employee em: lst) {
		System.out.println(em);
	}
}
}

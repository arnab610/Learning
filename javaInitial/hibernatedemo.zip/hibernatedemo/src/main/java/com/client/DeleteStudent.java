package com.client;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.entity.Employee;
import com.entity.Student;
import com.hibernate.HibernateUtility;

public class DeleteStudent {
	public static void main(String[] args) {
		Session session = HibernateUtility.getSession();
		Transaction tx = session.beginTransaction();
		Student em =(Student)session.get(Student.class, 14);
		if(em!=null) {
			session.delete(em);
		}
		
		tx.commit();
		System.out.println("User deleted");
	}

}

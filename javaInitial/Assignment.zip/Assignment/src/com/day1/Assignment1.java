package com.day1;

public class Assignment1 {
	public static void main(String[] args) {
		int intval =10;
		float floatVal = 250.5f;
		double doubleVal = 2500.5;
		boolean booleanVal =true;
		System.out.println("Interger\t:" + intval + "\nFloat\t:"+ floatVal);
	}

}

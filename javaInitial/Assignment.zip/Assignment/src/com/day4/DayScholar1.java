package com.day4;

public class DayScholar1 {

}

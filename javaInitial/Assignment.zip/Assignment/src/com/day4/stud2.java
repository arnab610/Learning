package com.day4;

public class stud2 {
	private int id;
	private char type;
	private String name;
	public stud2(int id, char type, String name) {
		super();
		this.id = id;
		this.type = type;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public char getType() {
		return type;
	}
	public void setType(char type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}

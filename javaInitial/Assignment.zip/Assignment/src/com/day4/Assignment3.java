package com.day4;

public class Assignment3 {
public static void main(String[] args) {
	DayScholar d = new DayScholar(12, 'd',"sab", 130.5, "CRp");
	d.show();
}
}

package com.day2;

public class Student {
	private int sid;
	private char stp;
	public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public char getStp() {
		return stp;
	}
	public void setStp(char stp) {
		this.stp = stp;
	}

}

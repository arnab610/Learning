package com.day2;

public class Asg7 {
public static void main(String[] args) {
	int sid =25;
	Asg7 ob = new Asg7();
	System.out.println(sid);
	ob.pass(sid);
	System.out.println("The sid is"+ sid);
}
public void pass(int sid) {
	sid=10;
	System.out.println("The sid are"+ sid);
}
}

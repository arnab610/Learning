package com.day2;

public class Asg1 {
	public static void main(String[] args) {
		int iv =100;
		byte bv= (byte)iv;
		byte m = 127;
		byte min = -128;
		byte sum = (byte) (m+min);
		System.out.println("Sum=" +sum);
		
	}
}

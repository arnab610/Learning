package com.day2;

public class CourseManagement {
public static void main(String[] args) {
	Student ob = new Student();
	ob.setSid(123);
	ob.setStp('F');
	System.out.println(ob.getSid()+" "+ ob.getStp());
}
}

package com.app;

public interface UserDao {
public void addUser(User user) throws DaoException;
}

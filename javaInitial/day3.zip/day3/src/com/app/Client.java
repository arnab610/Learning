package com.app;

public class Client {
	public static void main(String[] args) {
		User user = new User();
		UserDao ud = new DaoImpl();
		try {
			ud.addUser(user);
		} catch (DaoException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		System.out.println("user added");
	}

}

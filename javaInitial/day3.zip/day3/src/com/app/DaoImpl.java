package com.app;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class DaoImpl implements UserDao{

	@Override
	public void addUser(User user) throws DaoException {
		// TODO Auto-generated method stub
		try {
			FileOutputStream fos = new FileOutputStream("C:\\");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			//System.out.println("hello");
			throw new DaoException("Something went wrong", e);
		}
	}

}

package com.inter;

public class PublicSectorBank implements Bank, Insurance, MutualFunds{

	@Override
	public void CheckBalance() {
		// TODO Auto-generated method stub
		System.out.println("check");
	}

	@Override
	public void Withdraw() {
		// TODO Auto-generated method stub
		System.out.println("withdraw");
	}

	@Override
	public void Deposit() {
		// TODO Auto-generated method stub
		System.out.println("deposit");
	}

	@Override
	public void sellInsurance() {
		// TODO Auto-generated method stub
		System.out.println("Sell ins");
	}

	@Override
	public void settleClaims() {
		// TODO Auto-generated method stub
		System.out.println("settle claims");
	}

	@Override
	public void sellMf() {
		// TODO Auto-generated method stub
		System.out.println("Sell mutual funds");
	}

	@Override
	public void purchaseMf() {
		// TODO Auto-generated method stub
		System.out.println("purchase mutual funds");
	}

}

package com.inter;

public interface Insurance {
public void sellInsurance();
public void settleClaims();
}

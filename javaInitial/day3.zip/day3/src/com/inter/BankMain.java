package com.inter;

public class BankMain {
public static void main(String[] args) {
PublicSectorBank ob = new PublicSectorBank();
	ob.CheckBalance();
	ob.Deposit();
	ob.Withdraw(); 
	ob.settleClaims();
	ob.sellMf();
	ob.purchaseMf();
}
}

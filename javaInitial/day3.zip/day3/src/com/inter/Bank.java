package com.inter;

public  interface Bank {
	public  void CheckBalance();
	public  void Withdraw();
	public void Deposit();

}

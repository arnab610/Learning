package com.inter;

public interface MutualFunds {
public void sellMf();
public void purchaseMf();

}

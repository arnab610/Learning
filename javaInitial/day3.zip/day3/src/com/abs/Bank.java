package com.abs;

public abstract class Bank {
	public abstract void CheckBalance();
	public abstract void Withdraw();
	public abstract void Deposit();
	public void Business() {
		System.out.println("default imp");
	}

}

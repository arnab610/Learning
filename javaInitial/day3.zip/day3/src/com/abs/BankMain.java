package com.abs;

public class BankMain {
public static void main(String[] args) {
	Bank b = new PublicSectorBank();
	PublicSectorBank b2 =new PublicSectorBank();
	b.CheckBalance();
	b.Deposit();
	b.Business();
	System.out.println(b2.a);
	Bank b1 = new PSB();
	b1.Business();
	b1.CheckBalance();
	b1.Deposit();
	b1.Withdraw();
}
}

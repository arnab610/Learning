package com.abs;

public class PSB extends Bank{

	@Override
	public void CheckBalance() {
		// TODO Auto-generated method stub
		System.out.println("PS checkbal");
		
	}

	@Override
	public void Withdraw() {
		// TODO Auto-generated method stub
		System.out.println("ps withdraw");
	}

	@Override
	public void Deposit() {
		// TODO Auto-generated method stub
		System.out.println("Ps deposit");
	}

}

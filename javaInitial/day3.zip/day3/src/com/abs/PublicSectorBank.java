package com.abs;

public class PublicSectorBank extends Bank {
	int a =10;

	@Override
	
	public void CheckBalance() {
		// TODO Auto-generated method stub
		System.out.println("check");
		
	}

	@Override
	public void Withdraw() {
		// TODO Auto-generated method stub
		System.out.println("withdraew");
	}

	@Override
	public void Deposit() {
		// TODO Auto-generated method stub
		System.out.println("deposit");
		
	}

}

package com.exception;

public class ExceptionDemo3 {
	public static void demo() {
		throw new NullPointerException();
	}
public static void main(String[] args) {
	try {
		demo();
	} catch (NullPointerException e) {
		// TODO: handle exception
		System.out.println("Caught");
	}
}
}

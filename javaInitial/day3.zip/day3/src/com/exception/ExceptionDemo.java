package com.exception;

public class ExceptionDemo {
public static void main(String[] args) {
	int e1=10;
	try {
	int data =10/0;
	}catch(ArithmeticException e) {
	System.out.println("dont");
	;
	}
}
}

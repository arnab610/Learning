package com.exception;

public class ExceptionDemo2 {
public static void main(String[] args) {
	try {
		int a[] = new int[5];
		a[2] =20/2;
		
	} catch (ArithmeticException e) {
		// TODO: handle exception
		System.out.println("Divide by 0 called");
	}
	catch (ArrayIndexOutOfBoundsException e) {
		System.out.println("Check the length of the array");
		
	}
	catch (Exception e) {
		// TODO: handle exception
		System.out.println("Handles everything");
	}
	finally {
		System.out.println("Called everytime");
	}
}
}

package com.miniapp;

public class Front {
private Restaurant res;

public Front(Restaurant res) {
	super();
	this.res = res;
}
public String takeOrder(String dish) {
	return res.prepareFood(dish);
}
}

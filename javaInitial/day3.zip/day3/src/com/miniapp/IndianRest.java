package com.miniapp;

public class IndianRest implements Restaurant{

	public String prepareFood(String dishname) {
		// TODO Auto-generated method stub
		return "preparing "+ dishname+"with Indian spices";
	}

}

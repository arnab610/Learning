package com.miniapp;

public interface Restaurant {
public String prepareFood(String dishname);
}

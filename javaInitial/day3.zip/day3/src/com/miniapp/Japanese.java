package com.miniapp;

public class Japanese implements Restaurant{
	@Override
	public String prepareFood(String dishname) {
		// TODO Auto-generated method stub
		return "preparing "+ dishname+"ramen";
	}
}

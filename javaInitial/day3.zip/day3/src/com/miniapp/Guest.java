package com.miniapp;

public class Guest {
public static void main(String[] args) {
	Front fd = new Front(new Italian());
	System.out.println(fd.takeOrder("Pasta"));
	Front fd1 = new Front(new IndianRest());
	System.out.println(fd1.takeOrder("Mudhi"));
	Front fd2 = new Front(new Japanese());
	System.out.println(fd2.takeOrder("Miso"));
}
}

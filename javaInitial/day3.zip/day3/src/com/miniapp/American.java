package com.miniapp;

public class American implements Restaurant{

	@Override
	public String prepareFood(String dishname) {
		// TODO Auto-generated method stub
		return "preparing "+ dishname+"bacon";
	}

}

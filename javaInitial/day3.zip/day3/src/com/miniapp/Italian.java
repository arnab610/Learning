package com.miniapp;

public class Italian implements Restaurant {

	@Override
	public String prepareFood(String dishname) {
		// TODO Auto-generated method stub
		return "preparing "+ dishname+"with herbs";
	}

}

package com.day3;

public class PublicSecBank extends Bank{
	private double minbal;
	private String loctype;
	public PublicSecBank(int accno, String acctype, double minbal, String loctype) {
		super(accno, acctype);
		this.minbal = minbal;
		this.loctype = loctype;
	}
	@Override
	public String toString() {
		return "PublicSecBank [minbal=" + minbal + ", loctype=" + loctype + "]";
	}
	
	

}

package com.day3;

public class PrivateSecBank extends Bank{
	  int atmbank;
	 int mobbank;
	public PrivateSecBank(int accno, String acctype, int atmbank, int mobbank) {
		super(accno, acctype);
		this.atmbank = atmbank;
		this.mobbank = mobbank;
	}
	

}

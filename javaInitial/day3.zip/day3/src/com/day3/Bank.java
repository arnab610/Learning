package com.day3;

public class Bank {
private int accno;
private String acctype;
public Bank(int accno, String acctype) {
	super();
	this.accno = accno;
	this.acctype = acctype;
}

}

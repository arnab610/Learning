package com.day3;

public class BankMain {
public static void main(String[] args) {
	PublicSecBank ob = new PublicSecBank(12334, "Savings", 1000.0, "A");
	PrivateSecBank ob1 = new PrivateSecBank(45623, "Current", 1, 1);
	System.out.println(ob);
	System.out.println(ob1.atmbank +" "+ ob1.mobbank);
}
}

package com.asg;

public class SBI implements Banking {

	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
		System.out.println("SBI withdraw");
	}

	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		System.out.println("SBI deposit");
	}

	@Override
	public void checkbalance() {
		// TODO Auto-generated method stub
		System.out.println("SBI check");
		
	}

}

package com.asg;

public interface Banking {
public void withdraw();
public void deposit();
public void checkbalance();

}

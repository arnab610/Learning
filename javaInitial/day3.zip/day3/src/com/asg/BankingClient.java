package com.asg;

public class BankingClient {
public static void main(String[] args) {
	CustomerService ob = new CustomerService(new SBI());
	ob.show();
	CustomerService ob1 = new CustomerService(new ICICI());
	ob1.show();
}
}

package com.asg;

public class ICICI implements Banking{

	@Override
	public void withdraw() {
		// TODO Auto-generated method stub
		System.out.println("ICICI withdraw");
	}

	@Override
	public void deposit() {
		// TODO Auto-generated method stub
		System.out.println("ICICI deposit");
	}

	@Override
	public void checkbalance() {
		// TODO Auto-generated method stub
		System.out.println("ICICI checkbal");
	}

}

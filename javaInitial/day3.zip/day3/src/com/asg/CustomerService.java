package com.asg;

public class CustomerService {
private Banking b;

public CustomerService(Banking b) {
	super();
	this.b = b;
}
public void show() {
	b.checkbalance();
	b.deposit();
	b.withdraw();
}
}

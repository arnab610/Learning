package com.mypack;

public class ArrayDemo {
	static int[] loadData() {
		
		return new int[]{10,20,30};
		
		}
	public static void main(String[] args) {
		//int [] a = new int[10];
		//a[0] =1;
		//a[1] =2;
		
		//for (int i=0; i<a.length; i++) {
		//for(int i :a) {
			//System.out.println(i);
		//}
		int arr[] = loadData();
		for(int i :arr) {
			System.out.println(i);
		}
	}

}

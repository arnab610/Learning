package com.mypack;

public class Welcome {
	public static void main(String[] args) {
		System.out.println("Welcome to java" + " "+args[0]);
		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);
		System.out.println("Sum is"+ " "+(a+b));
		
	}

}

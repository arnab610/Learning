package com.mypack;

public class UserMain {
	public static void main(String[] args) {
		User ob = new User();
		ob.setuId(100);
		ob.setuEmail("abc@gmail.com");
		ob.setuName("Pranab");
		System.out.println(ob.getuName()+ " "+ ob.getuEmail()+" "+ ob.getuId()); 
	}

}

package com.day5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class Link {
public static void main(String[] args) {
	//ArrayList<Project> a = new ArrayList<>();
	LinkedList<Project> a = new LinkedList<>();
	a.add(new Project(0, "hari", "Delhi", 200));
	a.add(new Project(1, "Shiv", "Odisha", 800));
	a.add(new Project(2, "Ana", "Punjab", 400));
	a.add(new Project(3, "Ram", "Kolkata", 100));
	a.addFirst(new Project(4, "Shyam", "Bangalore", 600));
	//Collections.sort(a, new Comp());
	for(Project i:a) {
		System.out.println(i);
	}
}
	}


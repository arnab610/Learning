package com.day5;

import java.util.Comparator;

public class Comp implements Comparator<Project>{

	@Override
	public int compare(Project o1, Project o2) {
		// TODO Auto-generated method stub
		//return Integer.compare(o1.getBudget(), o2.getBudget());
		//if (o1.getBudget()> o2.getBudget())
			//return 1;
		//else if(o1.getBudget()< o2.getBudget())
			//return -1;
		//else 
			//return 0;
		return o1.getBudget()- o2.getBudget();
		//return o1.getpName()- o2.getpName();// cannot use in case of string
	}

}

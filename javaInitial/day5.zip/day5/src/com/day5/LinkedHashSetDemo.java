package com.day5;

import java.util.LinkedHashSet;
import java.util.TreeSet;

public class LinkedHashSetDemo {
public static void main(String[] args) {
	LinkedHashSet<Project> a = new LinkedHashSet<Project>();
	a.add(new Project(0, "hari", "Delhi", 200));
	a.add(new Project(1, "Shiv", "Odisha", 800));
	a.add(new Project(2, "Ana", "Punjab", 400));
	a.add(new Project(3, "Ram", "Kolkata", 100));
	a.add(new Project(3, "Ram", "Kolkata", 100));
	
	//Collections.sort(a, new Comp());
	for(Project i:a) {
		System.out.println(i);
	}
}
}

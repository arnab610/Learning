package com.day5;

import java.util.Objects;

public class Project implements Comparable<Project>{
private int pid;
private String pName;
private String loc;
private int budget;
public Project(int pid, String pName, String loc, int budget) {
	super();
	this.pid = pid;
	this.pName = pName;
	this.loc = loc;
	this.budget = budget;
	
}

public int getPid() {
	return pid;
}

public void setPid(int pid) {
	this.pid = pid;
}

public String getpName() {
	return pName;
}

public void setpName(String pName) {
	this.pName = pName;
}

public String getLoc() {
	return loc;
}

public void setLoc(String loc) {
	this.loc = loc;
}

public int getBudget() {
	return budget;
}

public void setBudget(int budget) {
	this.budget = budget;
}


@Override
public int hashCode() {
	return Objects.hash(budget, loc, pName, pid);
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Project other = (Project) obj;
	return budget == other.budget && Objects.equals(loc, other.loc) && Objects.equals(pName, other.pName)
			&& pid == other.pid;
}

@Override
public String toString() {
	return "Project [pid=" + pid + ", pName=" + pName + ", loc=" + loc + ", budget=" + budget + ", getClass()="
			+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
}

@Override
public int compareTo(Project o) {
	// TODO Auto-generated method stub
	return this.getpName().compareTo(o.getpName());
}

}

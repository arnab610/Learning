package com.day5;

import java.util.HashMap;
import java.util.Map;

public class HashMapDemo {
public static void main(String[] args) {
	HashMap<Integer, Project> a = new HashMap<Integer, Project>();
	a.put(10120, new Project(0, "hari", "Delhi", 200));
	a.put(10130, new Project(0, "hari", "Delhi", 200));
	a.put(10130, new Project(2, "har", "Delhi", 300));
	
	//Collections.sort(a, new Comp());
	System.out.println(a);
	for(Map.Entry data: a.entrySet()) {
		System.out.println(data.getKey()+ " "+ data.getValue());
	}
}
}

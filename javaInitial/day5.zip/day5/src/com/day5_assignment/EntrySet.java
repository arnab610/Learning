package com.day5_assignment;

import java.util.HashSet;
import java.util.Set;

public class EntrySet {
public void printSet(Set<String> set) {
	if(set.isEmpty())
		System.out.println("Empty set");
	else
		System.out.println("Set elemrnts are"+ set);
}
public static void main(String[] args) {
	Set<String> s = new HashSet<String>();
	s.add("First Entry");
	s.add("Seconfd Entry");
	s.add("third Entry");
	s.add("First Entry");
	EntrySet ob = new EntrySet();
	ob.printSet(s);
	Set<String> empty = new HashSet<String>();
	ob.printSet(empty);
	}


}

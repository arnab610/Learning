package com.day5_assignment;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class LoginDetails {
public void addSameKey(Map<Integer, String> map) {
	if(map.containsKey(1003))
		System.out.println("Key is already present");
	map.put(1003, "John");
}
public void printLoginDetails(Map<Integer, String> map) {
	Set<Integer> set = map.keySet();
	Iterator<Integer> it = set.iterator();
	while(it.hasNext())
		System.out.println(it.next());
	
}
public static void main(String[] args) {
	Map<Integer, String> m = new LinkedHashMap<Integer, String>();
	m.put(1000,"Sam");
	m.put(1001,"tom");
	m.put(1002,"Zen");
	m.put(1003,"Zen");
	System.out.println("Map before adding the same key"+ m);
	LoginDetails l = new LoginDetails();
	l.addSameKey(m);
	System.out.println("Value foe 1003 after addsamekey()"+ m.get(1003));
	System.out.println("Map after adding the same key1003"); l.printLoginDetails(m);
	
}
}

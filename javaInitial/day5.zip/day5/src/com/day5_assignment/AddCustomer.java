package com.day5_assignment;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;



public class AddCustomer {
public void printCustomers(List<String> arrayList) {
	Iterator<String> iterator = arrayList.iterator();
	System.out.println("Customers are :");
	while(iterator.hasNext()) {
		System.out.println(iterator.next());
	}
	
}
public static void main(String[] args) {
	ArrayList<String> l = new ArrayList<String>();
	l.add("Harry");
	l.add("Tabrez");
	AddCustomer ob = new AddCustomer();
	ob.printCustomers(l);
}
}


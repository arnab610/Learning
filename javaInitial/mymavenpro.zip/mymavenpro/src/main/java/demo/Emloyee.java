package demo;

public class Emloyee {
private String uname;
private String email;
private String city;
private int income;
public String getUname() {
	return uname;
}
public void setUname(String uname) {
	this.uname = uname;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public int getIncome() {
	return income;
}
public void setIncome(int income) {
	this.income = income;
}
public Emloyee(String uname, String email, String city, int income) {
	super();
	this.uname = uname;
	this.email = email;
	this.city = city;
	this.income = income;
}
@Override
public String toString() {
	return "Emloyee [uname=" + uname + ", email=" + email + ", city=" + city + ", income=" + income + "]";
}

}

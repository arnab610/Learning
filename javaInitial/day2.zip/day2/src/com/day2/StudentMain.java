package com.day2;

public class StudentMain {
	public static void main(String[] args) {
		Student ob = new Student();
		Student ob1 = new Student();
		ob.setSe("abc@gmail.com");
		ob.setSn("Hari");
		ob.setSub("CS");
		ob.setSrn(123);
		ob1=ob;
		System.out.println(ob.hashCode() +" "+ ob1.hashCode());
		System.out.println(ob.getSn()+ " "+ ob.getSub()+ " "+ ob.getSrn()+ " "+ ob.getSe());
	}

}

package com.day2;

public class Student {
	private int srn;
	private String sn;
	private String se;
	private String sub;
	public int getSrn() {
		return srn;
	}
	public String getSn() {
		return sn;
	}
	public String getSe() {
		return se;
	}
	public String getSub() {
		return sub;
	}
	public void setSrn(int srn) {
		this.srn = srn;
	}
	public void setSn(String sn) {
		this.sn = sn;
	}
	public void setSe(String se) {
		this.se = se;
	}
	public void setSub(String sub) {
		this.sub = sub;
	}
	

}

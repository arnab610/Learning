package com.demo;

public class StudentMain {
public static void main(String[] args) {
	Student ob = new Student(7, "Tanjiro", "xyz@gmail.com", "CS");
	Student ob1 = new Student();
	System.out.println(ob.hashCode() + " "+ ob1.hashCode());
	System.out.println(ob + " "+ ob1);
	
}
}

package com.demo;

public class Student {
	private int srn;
	private String sn;
	private String se;
	private String sub;
	public Student(int srn, String sn, String se, String sub) {
		super();
		this.srn = srn;
		this.sn = sn;
		this.se = se;
		this.sub = sub;
	}
	public Student() {
		System.out.println("Default");
	}
	@Override
	public String toString() {
		return "Student [srn=" + srn + ", sn=" + sn + ", se=" + se + ", sub=" + sub + "]";
	}
	

}

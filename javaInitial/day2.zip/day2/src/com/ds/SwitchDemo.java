package com.ds;

public class SwitchDemo {
	public static void main(String[] args) {
		int v=2;
		String loc;
		switch(v) {
		case 2:
			loc="Odisha";
			break;
		case 3:
			loc ="Delhi";
			break;
		default:
			loc="NA";
			break;
		}
		System.out.println(loc);
	}

}

package com.ds;

public class Data {
	private final static int SIZE =15;
	private int[] a =new int[] {10,11,12,13,14,15,16};
	//public Data() {
		//for(int i=0; i<SIZE; i++) {
		//	a[i]= i;
		
		//}
	//}
	public void printEven() {
		Inner i = new Inner();
		while(i.hasNext()) {
			System.out.println(i.getNext());
			
		}
		System.out.println(i.countAvg());
		
	}
	private class Inner{
		private int next =0;
		private int count =0;
		public boolean hasNext() {
			return (next<=a.length-1);
		}
		public int getNext() {
			int r = a[next];
			next+=2;
			return r;
		}
		public double countAvg() {
			for(int i=0; i<a.length; i++) {
				count+=a[i];
			}
				return (count/a.length);
				
			}
		}
	
	public static void main(String[] args) {
		Data ob = new Data();
		ob.printEven();
	}

}

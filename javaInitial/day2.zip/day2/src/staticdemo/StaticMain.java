package staticdemo;

public class StaticMain {
	public static void main(String[] args) {
		StaticDemo.show();
		
	}
	static {
		System.out.println("moshi");
	}

}

package staticdemo;

public class StaticDemo {
	public static void show() {
		System.out.println("hello");
	}
	static {
		System.out.println("yo");
	}

}

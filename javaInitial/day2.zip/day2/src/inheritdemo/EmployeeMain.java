package inheritdemo;

public class EmployeeMain {
	public static void main(String[] args) {
		Admin ob = new Admin(8, "Giyu", "Swordsman");
		System.out.println(ob);
		Manager ob1= new Manager(12, "Ino", 40);
		System.out.println(ob1);
	}

}

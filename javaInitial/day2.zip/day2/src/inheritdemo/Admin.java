package inheritdemo;

public class Admin extends Employee {
	private String domain;

	public Admin(int empid, String empname, String domain) {
		super(empid, empname);
		this.domain = domain;
	}

	@Override
	public String toString() {
		return "Admin [domain=" + domain + "]" + empname+ " ";
	}
	

}

package inheritdemo;

public class Manager extends Employee {
private int no_ofemp;

public Manager(int empid, String empname, int no_ofemp) {
	super(empid, empname);
	this.no_ofemp = no_ofemp;
}

@Override
public String toString() {
	return "Manager [no_ofemp=" + no_ofemp + "]"+ "[employeename=" +empname+"]";
}

}

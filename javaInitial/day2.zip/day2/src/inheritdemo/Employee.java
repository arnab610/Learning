package inheritdemo;

public class Employee {
 private int empid;
 protected String empname;
public Employee(int empid, String empname) {
	super();
	this.empid = empid;
	this.empname = empname;
}
 
}

package exception;

public class InvalidAcc extends CustomException {

	public InvalidAcc() {
		super();
		// TODO Auto-generated constructor stub
	}

	public InvalidAcc(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidAcc(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public InvalidAcc(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}

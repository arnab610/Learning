package Assignment;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CustomerFiledb {
String file ="data\\customer.dat";
public int saveCustomer(Customer customer) {
	int status =-1;
	FileWriter fil = null;
	BufferedWriter bw =null;
	try {
		fil = new FileWriter(file,true);
		bw = new BufferedWriter(fil);
		String data = Integer.toString(customer.getCustId())+ customer.getCustName()+"\n";
		bw.write(data);
		bw.flush();
		status =0;
		
	} catch (IOException e) {
		// TODO: handle exception
		status =-2;
		e.printStackTrace();
	}
	finally {
		if(null != bw) {
			try {
				bw.close();
			} catch (IOException e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		if(null != fil) {
			try {
				fil.close();
				
			} catch (IOException e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
	}
	return status;
}

public Customer getCustomer(int custid) {
	Customer customer =null;
	FileReader fr = null;
	BufferedReader br =null;
	try {
		fr = new FileReader(file);
		br = new BufferedReader(fr);
		String[] data = null;
		String input = br.readLine();
		while(input !=null) {
			data=input.split(":");
			if(Integer.parseInt(data[0])==custid) {
				customer = new Customer();
				customer.setCustId(Integer.parseInt(data[0]));
				customer.setCustName((data[1]));
				break;
			}
			input = br.readLine();
			
		}
	} catch (IOException e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	finally {
		if(null != br) {
			try {
				br.close();
			} catch (IOException e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		if(null != fr) {
			try {
				fr.close();
			} catch (IOException e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
	}
	return customer;
}
}

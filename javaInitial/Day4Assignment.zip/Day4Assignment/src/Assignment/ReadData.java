package Assignment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;



public class ReadData {
public static String acceptString() {
	String stringdata =null;
	BufferedReader br = null;
	try {
		br =new BufferedReader(new InputStreamReader(System.in));
		stringdata = br.readLine();
		
	} catch (IOException e) {
		// TODO: handle exception
		System.out.println("Error in handling data");
	}
	finally {
		if(br != null)
			br=null;
	}
	return stringdata;
	
}
}

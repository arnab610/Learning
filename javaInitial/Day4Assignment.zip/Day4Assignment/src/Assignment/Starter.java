package Assignment;

public class Starter {
public static void main(String[] args) {
	CustomerTester ob = new CustomerTester();
	ob.customerMenu();
}
}

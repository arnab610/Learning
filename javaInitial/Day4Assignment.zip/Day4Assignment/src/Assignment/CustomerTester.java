package Assignment;

public class CustomerTester {
public void acceptCustomerInfo() {
	System.out.println("\n\n Please enter the details of customer");
	System.out.print("customerid:");
	String custId = ReadData.acceptString();
	System.out.println("Customer Name");
	String custName = ReadData.acceptString();
	Customer customer = new Customer();
	customer.setCustId(Integer.parseInt(custId));
	customer.setCustName(custName);
	int status = new CustomerFiledb().saveCustomer(customer);
	if(status ==0) {
		System.out.println("Your details are saved");
		ReadData.acceptString();
		System.out.println("\n\n\n\n");
		
	}
	else {
		System.out.println("Your details couldnot be saved please try again");
		ReadData.acceptString();
		System.out.println("\n\n\n\n");
	}
	
	
}
public void displayCustInfo() {
	System.out.println("\n\nplease enter customer id");
	String custId = ReadData.acceptString();
	Customer customer = new CustomerFiledb().getCustomer(Integer.parseInt(custId));
	if(customer !=null) {
		System.out.println("\n Customer id"+ customer.getCustId());
		System.out.println("Customer name"+ customer.getCustName());
		
	}
	else {
		System.out.println("invalid customer");
		ReadData.acceptString();
		System.out.println("\n\n\n");
	}
}
public void customerMenu() {
	while(true) {
		System.out.println("\t Customer menu");
		System.out.println("------------------");
		System.out.println("1mto add customer");
		System.out.println("2 to get customer");
		System.out.println("3 to exit");
		System.out.println("\n enter option");
		String optedvalue= ReadData.acceptString();
		int option = Integer.parseInt(optedvalue);
		switch(option) {
		case 1:
			acceptCustomerInfo();break;
		case 2:
			displayCustInfo(); break;
		case 3:

		System.exit(0);break;
		default:
			System.out.println("Enter a valid option");
			ReadData.acceptString();
		}
	}
	
}

}

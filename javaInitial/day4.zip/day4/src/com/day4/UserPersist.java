package com.day4;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class UserPersist {
public static void main(String[] args) throws IOException {
	String s[] = new String[3];
	s[0]="java";
	s[1]="c";
	s[2]="Python";
	User user = new User(0,"abc" , "abc@mail");
	System.out.println(user);
	FileOutputStream fos = new FileOutputStream("userdata.txt");
	ObjectOutputStream oos = new ObjectOutputStream(fos);
	oos.writeObject(user);
	System.out.println("done");
}
}

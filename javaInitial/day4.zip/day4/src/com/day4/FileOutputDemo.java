package com.day4;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputDemo {
public static void main(String[] args) {
	try {
		FileOutputStream fos = new FileOutputStream("text.text");
		String data ="Welcome to java";
		byte b[]= data.getBytes();
		fos.write(b);
		fos.close();
		System.out.println("data written");
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	catch (IOException e) {
		// TODO: handle exception
	}
}
}

package com.exception;

public class AdminAlreadyExistsException extends Exception {

	private static final long serialVersionUID = 1L;

	public AdminAlreadyExistsException(String message) {
        super(message);
    }
}

package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Admin;
import com.exception.AdminAlreadyExistsException;
import com.exception.AdminNotFoundException;
import com.repository.AdminRepository;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin("*")
public class AdminController {
	@Autowired
	private AdminRepository proRepository;
	
	@PostMapping("/admin")
	public Admin saveAdmin(@RequestBody Admin admin) throws AdminAlreadyExistsException{
		return proRepository.save(admin);
	}
	
	@GetMapping("/admins")
	public List<Admin> getAllAdmin() {
		return proRepository.findAll();
	}
	
	@GetMapping("/admin/{id}")
	public Admin getAdminById(@PathVariable Long id) throws AdminNotFoundException{
		return proRepository.findById(id).get();
	}
}

package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Cart;

import com.exception.UserNotFoundException;
import com.repository.CartRepository;
@RestController
@RequestMapping("/api/v1")
@CrossOrigin("*")
public class CartController {





	@Autowired
	private CartRepository cr;
	
	@PostMapping("/cart")
	public Cart saveMovie(@RequestBody Cart cart) {
		return cr.save(cart);
	}
	
	@GetMapping("/carts")
	public List<Cart> getAllUser() {
		return cr.findAll();
	}
	
	@GetMapping("/cart/{id}")
	public Cart getUserById(@PathVariable Long id) {
		return cr.findById(id).get();
	}
	

	@PutMapping("/carts")
	public Cart updateEmployee(@RequestBody Cart cart) {
		return cr.save(cart);
	}
	
	@DeleteMapping("/carts/{id}")
	public ResponseEntity<HttpStatus> deleteUserById(@PathVariable Long id) throws UserNotFoundException{
		cr.deleteById(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

}
import { useState } from "react";
import { Link, useHistory, useParams } from "react-router-dom";
import { useEffect } from "react/cjs/react.development";
import employeeService from "../services/employee.service";
import 'react-confirm-alert/src/react-confirm-alert.css';
const AddEmployee = () => {
    const[name, setName] = useState('');
    const[location, setLocation] = useState('');
    const[department, setDepartment] = useState('');
    const[city, setCity] = useState('Delhi');
    const[doj, setDoj] = useState('');
    const[income, setIncome] = useState('0.0');
    const[url, seturl] = useState('');





    const history = useHistory();
    const {id} = useParams();

    const saveEmployee = (e) => {
        e.preventDefault();
        
        const employee = {name, location, department, id,city,doj,income,url};
        if (id) {
            //update
            employeeService.update(employee)
                .then(response => {
                    console.log('Employee data updated successfully', response.data);
                    history.push('/');
                })
                .catch(error => {
                    console.log('Something went wrong', error);
                }) 
        } else {
            //create
            employeeService.create(employee)
            .then(response => {
                console.log("employee added successfully", response.data);
                history.push("/");
            })
            .catch(error => {
                console.log('something went wroing', error);
            })
        }
    }

    useEffect(() => {
        if (id) {
            employeeService.get(id)
                .then(employee => {
                    setName(employee.data.name);
                    setLocation(employee.data.location);
                    setDepartment(employee.data.department);
                    setCity(employee.data.city);
                    setIncome(employee.data.income);
                    setDoj(employee.data.doj)
                    seturl(employee.data.url)
                })
                .catch(error => {
                    console.log('Something went wrong', error);
                })
        }
    }, [])
    return(
        <div className="container">
            <h3>Add Employee</h3>
            <hr/>
            <form>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Enter name"
                    />

                </div>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="department"
                        value={department}
                        onChange={(e) => setDepartment(e.target.value)}
                        placeholder="Enter Department"
                    />

                </div>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="location"
                        value={location}
                        onChange={(e) => setLocation(e.target.value)}
                        placeholder="Enter Location"
                    />
                </div>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="income"
                        value={income}
                        onChange={(e) => setIncome(e.target.value)}
                        placeholder="Enter Income"
                    />

                </div>



                <div className="form-group">
                    <input 
                        type="date" 
                        className="form-control col-4"
                        id="date"
                        value={doj}
                        onChange={(e) => setDoj(e.target.value)}
                    />

                </div>




                <div className="form-group">
                
                <label for="cars">Choose city :</label>
               
               <select name="City" id="city"  value={city}
                        onChange={(e) => setCity(e.target.value)}> 
               <option value="Delhi">Delhi</option>
              <option value="Banglore">Banglore</option>
              <option value="Tokyo">Tokyo</option>
              <option value="Kanpur">Kanpur</option>

            </select>


                </div>

                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="url"
                        value={url}
                        onChange={(e) => seturl(e.target.value)}
                        placeholder="Profile "
                    />

                </div>











                <div >
                    <button onClick={(e) => saveEmployee(e)} className="btn btn-primary">Save</button>
                </div>
            </form>
            <hr/>
            <Link to="/">Back to List</Link>
        </div>
    )
}

export default AddEmployee;
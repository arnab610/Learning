import logo from './logo.svg';
import './App.css';
import MainApp from './components/MainApp';
import WedApp from './components/DisplayUsers';
import {BrowserRouter,Route,Switch,Link} from "react-router-dom"
import Login from './components/Login';

function App() {
  return (
    <BrowserRouter>
    <div className="App">
      
    <Switch>
            <Route exact path="/" component={WedApp} />
            <Route   path="/login" component={Login} />
           
          </Switch>
         
   
   
   
   
    </div>
    </BrowserRouter>
    
  );
}

export default App;

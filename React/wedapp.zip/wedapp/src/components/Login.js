const Login=()=>{
    return(
        <div>
            <h3>U are logged In</h3>
        </div>
    );

}
export default Login;
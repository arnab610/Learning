import React, { useEffect, useState } from 'react'
import { Link, useHistory, useParams } from "react-router-dom";

const WedApp = () => {
  const history = useHistory();
  const [data, setData] = useState(null)

  const [pass, setPass] = useState('')
  const [email, setEmail] = useState('')
  const [id, setId] = useState('Not logged in')
  const fetchURL = "http://localhost:8090/api/v1/admins"
  const getData = () =>
    fetch(`${fetchURL}`,{headers: {
      'Content-Type': 'application/json'
  }})
      .then((res) => res.json())

  useEffect(() => {
    getData().then((data) => setData(data))
  }, [])

  const HandleLogin=()=>{
  
    data.map(item=>{
      //console.log(item.name);
      //console.log(item.email);
      console.log(item)
     
      if (item.password===pass && item.email===email) {
        setId('Login successfull')
        console.log("Login was done");
        history.push("/login");
    
       
      } 
      console.log(1);
    })
}

  return (
    <div>
     
    Password:<input type="password" onChange={(e)=>setPass(e.target.value)}></input>
     email:<input type="email" onChange={(e)=>setEmail(e.target.value)}></input>
     <button onClick={HandleLogin}>Login</button>
     <input type="text" value={id} onChange={(e)=>setId(e.target.value)}></input>
     



    </div>
  )
}

export default WedApp;
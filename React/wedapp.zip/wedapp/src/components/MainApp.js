import { useEffect, useState } from "react"
import '../index.css'
const NotesApp=()=>{

    
   
    const [notes,setNotes]= useState([])
    const [name, setName] = useState('')
    const [email, setEmail] = useState('')
    const [dept, setDept] = useState('')
    useEffect(()=>{
       /// console.log('called during load');
       const notesdata = JSON.parse(localStorage.getItem('notes'))
       setNotes(notesdata)
        
    },[])
    useEffect(()=>{
        //console.log('called during title and email change');
        localStorage.setItem('notes',JSON.stringify(notes))
        
    },)
    const addNote=(e)=>{
        e.preventDefault()
        setNotes([
            ...notes,{name,email,dept}
        ])
        setName('')
        setEmail('')
        setDept('')
    }
    const removeNote=(name)=>{
        setNotes(notes.filter((note)=> note.name !== name))

    }
    return (
        <div>
           
            <p>Add User</p>
            <div className="container size">
            <form onSubmit={addNote}>
                name:<input type="text" className="form-control" value={name} onChange={(e)=> setName(e.target.value)} /><br></br>
                Email:<input type="email" className="form-control" value={email} onChange={(e)=> setEmail(e.target.value)} /><br></br>
                Department:<input type="text"  className="form-control" value={dept} onChange={(e)=> setDept(e.target.value)} /><br></br>
                <button> Add</button>
               
            </form>
            </div>

            <h3>Users Lists...</h3>
            {notes.map((note)=>{
                return(
                <div>
                    <table  className="table" border="1"> 
                 <tr>
                     <th>Name</th>
                     <th>Email</th>
                     <th>Department</th>
                 </tr>
                 <tr>
                
                <td><h3>{note.name}  </h3></td> 
                 <td><h3>{note.email}</h3></td> 
                <td> <h3>{note.dept}</h3></td>
                 </tr>
                 </table>
                <span> <button onClick={()=> removeNote(note.name)}> delete</button></span>
                 </div>
                  
                 
                 )
                
})}
        </div>
    )
}
export default NotesApp
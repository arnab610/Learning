const express= require('express')
const cors = require('cors')
const app = express()



app.get('/api/customer', cors(),(req,res)=>{
    const customers=[
        {id:101, firstName:'Arnab',email:'arnab@gmail.com'},
        {id:102, firstName:'brad',email:'brad@gmail.com'},
        {id:103, firstName:'john',email:'john@gmail.com'},
    ]
res.json(customers)
    
})
app.listen(5000,()=>{
    console.log('server is running')
})
import MainApp from "./tasks/MainApp";
import HooksDemo from "./hooksdemo/App1";
import NotesApp from "./hooksdemo/NotesApp";
import RestApp from "./Mycomp/RestApp";

import ContextDemo from "./Contextapp/ContextDemo";
import Landing from "./routingdemo/Landing";
import { useDispatch, useSelector } from "react-redux";
import { decrement, increment, login, logout, reset } from "./reactredux/actions/useractions";


function App(){
  const counter = useSelector((state)=>state.cntr)
  const auth =useSelector((state)=>state.auth)
  const dispatch= useDispatch()
  return(
    <div>
        Welcome  
  <p>The current count is {counter}</p>
  <button onClick={()=>dispatch(increment())}>Inc</button>
  <button onClick={()=>dispatch(decrement())}>Dec</button>
  <button onClick={()=>dispatch(reset())}>Res</button>
  <hr/>
    <div>
      <h2>For AUth users only</h2>
      <button onClick={()=>dispatch(login())}>Login</button> 
      <button onClick={()=>dispatch(logout())}>Logout</button> 
      {
        auth ? (
          <div>
            <p>Welcome to application you have logged in</p>
          </div>
        ):(
          "Not a valid user"
        )

      
      }

         </div>





    </div>
  )
}
export default App
import { useState } from "react";


function HooksDemo(props){
    const [count,setCount]= useState(props.count)
   // const increment=()=>{
      //  setCount(count+1)
  //  }
    const decrement=()=>{
        setCount(count-1)
    }
    const reset=()=>{
        setCount(10)
    }

    return(
        <div>
            <p>The current state is {count}</p>
            <button onClick={()=>setCount(count+1)}>INC</button>
            <button onClick={decrement}>DEC</button>
            <button onClick={reset}>RES</button>
        </div>
    )
}
HooksDemo.defaultProps={
    count:0
}
export default HooksDemo
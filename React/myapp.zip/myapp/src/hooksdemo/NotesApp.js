import { useEffect, useState } from "react"

const NotesApp=()=>{

    
   
    const [notes,setNotes]= useState([])
    const [title, setTitle] = useState('')
    const [email, setEmail] = useState('')
    useEffect(()=>{
       /// console.log('called during load');
       const notesdata = JSON.parse(localStorage.getItem('notes'))
       setNotes(notesdata)
        
    },[])
    useEffect(()=>{
        //console.log('called during title and email change');
        localStorage.setItem('notes',JSON.stringify(notes))
        
    },)
    const addNote=(e)=>{
        e.preventDefault()
        setNotes([
            ...notes,{title,email}
        ])
        setTitle('')
        setEmail('')
    }
    const removeNote=(title)=>{
        setNotes(notes.filter((note)=> note.title !== title))

    }
    return (
        <div>
            <h3>Notes Lists...</h3>
            {notes.map((note)=>{
                return(
                <div>
                
                 <h3>{note.title}  </h3>
                 <h3>{note.email}</h3>
                 <button onClick={()=> removeNote(note.title)}> delete</button>
                 </div>)
                
})}
            <p>Add Notes</p>
            <form onSubmit={addNote}>
                Title:<input type="text" value={title} onChange={(e)=> setTitle(e.target.value)} /><br></br>
                Email:<input type="email" value={email} onChange={(e)=> setEmail(e.target.value)} />
                <button> Add</button>
            </form>
        </div>
    )
}
export default NotesApp
import AuthReducer from "./authReducer";
import counterReducer from "./counterReducer";
const {combineReducers} = require('redux')



const appreducer= combineReducers({
    cntr: counterReducer,
    auth: AuthReducer
})
export default appreducer
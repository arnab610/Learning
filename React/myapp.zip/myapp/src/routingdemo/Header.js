
import {BrowserRouter,NavLink,Route,  Switch} from 'react-router-dom'
const Header=()=>{
    return (
        <header>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
 
            <div class="navbar-nav">
      
            <a class="nav-item nav-link" ><NavLink to="/" exact={true}>Login</NavLink></a>
            <a class="nav-item nav-link" ><NavLink to="/register" >Register</NavLink></a>
            <a class="nav-item nav-link" > <NavLink to="/portfolio" >Portfolio</NavLink></a>
            <a class="nav-item nav-link" > <NavLink to="/userdetails" >userdetails</NavLink></a>
            </div>
            </nav>
        </header>
    )
}
export default Header
function UserDetails(props){
    
    return(
        <div>
            <h3>Welcome to User details id: {props.match.params.id} </h3>
           
        </div>
    )
}
export default UserDetails
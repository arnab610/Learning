function Login(){
    
    return(
        <div>
            <h3>Welcome to Login </h3>
            <form >
                Name:<input type='text' className='form-control input-sm'/>
                Password:<input type='password' className='form-control'/><br></br>
                <button type="button" className="btn btn-outline-warning">Submit</button>

            </form>
           
        </div>
    )
}
export default Login
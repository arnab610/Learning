function Register(){
    
    return(
        <div>
            <h3>Welcome to Register</h3>

            <form >
                Name:<input type='text' className='form-control input-sm'/>
                Password:<input type='password' className='form-control'/>
                City:<input list='citi' name='city' type='text' className='form-control'/><br></br>
                <button type="button" className="btn btn-outline-warning">Submit</button>
            <datalist id='citi'>
                <option value ="Balsore"/>
                <option value ="Cuttack"/>
                <option value ="Bhubaneswar"/>
            </datalist>
            </form>
           
           
        </div>
    )
}
export default Register
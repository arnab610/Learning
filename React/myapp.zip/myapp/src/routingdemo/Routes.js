import {BrowserRouter,NavLink,Route,  Switch} from 'react-router-dom'
import Login from "./Login"
import Register from "./Register"
//import {BrowserRouter,NavLink,Route,  Switch} from 'react-router-dom'
import Portfolio from "./Portfolio"
import UserDetails from "./UserDetails"
import NotFound from "./4o4"
import Header from "./Header"
//import Routes from "./Routes"

const Routes=()=>{
    return(
    <BrowserRouter>
    <Header/>
    <Switch>
    <Route path='/' component={Login } exact={true}/>
    <Route path='/register' component={ Register}/>
    <Route path='/portfolio' component={ Portfolio }/>
    <Route path='/userdetails/:id' component={ UserDetails }/>
    <Route  component={NotFound}/>
    </Switch>

    </BrowserRouter>)
}
export default Routes
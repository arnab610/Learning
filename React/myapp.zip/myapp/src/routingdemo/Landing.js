import Login from "./Login"
import Register from "./Register"
import {BrowserRouter,NavLink,Route,  Switch} from 'react-router-dom'
import Portfolio from "./Portfolio"
import UserDetails from "./UserDetails"
import NotFound from "./4o4"
import Header from "./Header"
import Routes from "./Routes"

function Landing(){
    
    return(
        <div>
            <h3>Welcome to Landing </h3>
            <hr/>
            <Routes/>
           
        </div>
    )
}
export default Landing

/*const Header=()=>{
    return (
        <header>
            <NavLink to="/" exact={true}>Login</NavLink>
            <NavLink to="/register" >Register</NavLink>
            <NavLink to="/portfolio" >Prt</NavLink>
            <NavLink to="/userdetails" >userdetails</NavLink>
        </header>
    )
}*/

/*const routes=(
    <BrowserRouter>
    <Header/>
    <Switch>
    <Route path='/' component={Login} exact={true}/>
    <Route path='/register' component={Register}/>
    <Route path='/portfolio' component={Portfolio}/>
    <Route path='/userdetails' component={UserDetails}/>
    <Route  component={NotFound}/>
    </Switch>

    </BrowserRouter>
)*/
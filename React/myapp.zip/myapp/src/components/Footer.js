import { Component } from "react";


export default class Footer extends Component{
    //function Footer(props){}
state={
    filter:'',
    data: [
        {country: 'india',capital:'delhi',population:'1000'},
        {country: 'japann',capital:'tokoyo',population:'2000'},
        {country: 'new zealand',capital:'wellington',population:'3000'},
        
    ]
}
searchData(e){
    this.setState({
        filter:e.target.value
       
    })
}
    render(){
        let {filter,data} =this.state
        let dataSearch=data.filter(item =>{
            return Object.keys(item).some(key =>
                item[key].toLowerCase().includes(filter.toLowerCase()))
        })
        return(
            <div>
                <h3>Search App</h3>
                <input type='text' value={filter} placeholder='enter data to search' onChange={this.searchData.bind(this)}/>
                <hr/>
                <hr/>
                <table>
                    <tr>
                        <th>Country</th>
                        <th>Capital</th>
                        <th>Population</th>
                    </tr>
                    {
                        (dataSearch.map(item =>
                            <tr>
                                <td>{item.country}</td>
                                <td>{item.capital}</td>
                                <td>{item.population}</td>
                            </tr>
                            ))
                    }
                </table>
                <hr/>
            </div>
        )
    }
}


import {Component} from 'react';

import Option from './Option';


function Options(props){
          return(
            <div>{
               props.udata.map((data) => <Option mydata={data} del={props.du}/>)
            }
            <button onClick={props.eu}>Delete User</button>
            {
               props.udept.map((data) => <Option mydept={data}/>)
            }
             <button onClick={props.ed}>Delete Deptarment</button>
            </div>
        )
    }
export default Options
 
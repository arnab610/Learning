
/*import {Component} from 'react';

export default class Header extends Component{
    render(){
        return(
            <div>
                <h3> {this.props.hmessage}</h3>
            </div>
        )
    }
}*/
function Header(props){
    return(
        <div>
            <h3> {props.hmessage}</h3>
        </div>
    )
}
export default Header
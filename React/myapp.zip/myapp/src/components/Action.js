
import {Component} from 'react';

export default class Action extends Component{
    render(){
        return(
            <div>
                <h3> Welcome toAction </h3>
                <button disabled={!this.props.isData}>Show Action</button>
                <button disabled={!this.props.isDat}>Show Dept</button>
            </div>
        )
    }
}
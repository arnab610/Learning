
//import {Component} from 'react';


 function Option(props){
  const delUser=()=>{
        props.del(props.mydata)
    }
    
     return(
            <div>
            
               <div>
            
                    {props.mydata}
                    <button onClick={delUser}> delete</button>
                    </div>
                    
             <div>
            
                    {props.mydept}
                    </div>
                
            </div>
        )
    }
export default Option
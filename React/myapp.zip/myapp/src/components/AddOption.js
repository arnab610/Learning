
import {Component} from 'react';

function AddOption(props){
    //data =[]
    const addUser=(e)=>{
        e.preventDefault()
        const data = e.target.elements.uname.value
        //const email = e.target.elements.email.value
        //const city = e.target.elements.city.value
        //const d=[data,email,city]

        //alert(data)
        //document.getElementById("name").innerHTML=name
        //document.getElementById("email").innerHTML=email
        //document.getElementById("city").innerHTML=city
        props.addusr(data)

       
    }
    
        return(
            <div>
                <h3> {props.aomsg}</h3><br></br>
                <form onSubmit={addUser}>
                   Name: <input type="text" name='uname'></input><br></br>
                  Email: <input type="email" name='email'></input><br></br>
                    City:<input type="text" name='city'></input><br></br>
                <button >call me</button>
                </form>
                <div id="show"></div>
                <table  style={{border:"1px solid black"}}>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>City</th>
                    </tr>
                    <tr>
                        <td id="name"></td>
                        <td id="email"></td>
                        <td id="city"></td>
                    </tr>
                </table>
       
            </div>
        )
    }
    export default AddOption
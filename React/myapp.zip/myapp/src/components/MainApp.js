
import {Component} from 'react';
import Action from './Action';
import Adddepartments from './Adddepartments';
import AddOption from './AddOption';
import Counter from './Counter';
import Footer from './Footer';
import Header from './Header';
import Options from './Options';

export default class MainApp extends Component{
    state={
         userdata :[],
         departments:[]

    }
    emptyUserArray=()=>{
        this.setState(()=>{
            return{
                userdata:[]
            }
        })
    }
    emptyDeptArray=()=>{
        this.setState(()=>{
            return{
                departments:[]
            }
        })
    }

    addUser=(data)=>{
        this.setState((prevstate)=>{
            return{
                userdata:prevstate.userdata.concat(data)
            }
        })
    }
    addDept=(data)=>{
        this.setState((prevstate)=>{
            return{
                departments:prevstate.departments.concat(data)
            }
        })
    }
    deleteUser=(data)=>{
        this.setState((prevState)=>{
            return{
            userdata:prevState.userdata.filter((input)=> data !==input)
            }
        })
    }

    



    render(){
        
        return(
            <div>
                <Header hmessage="Welcome to HEader"/>
                <h3> Welcome to Main App</h3>
                
                
                
                <Options udata={this.state.userdata} udept={this.state.departments} eu={this.emptyUserArray}
                 ed={this.emptyDeptArray} du={this.deleteUser}/>
                <Action isData={this.state.userdata.length>0} isDat={this.state.departments.length>0}/>
            
                <AddOption aomsg="WElcome to add Option" addusr={this.addUser} />
                <Adddepartments adddpt={this.addDept} />
                <Counter/>
                <Footer />
            </div>
        )
    }
}

import {Component} from 'react';

export default class Counter extends Component{
    state={
        count:10
    }
    add =()=>{
        this.setState((prevstate)=>{
            return{
                count:prevstate.count+1
            }
        })
    }
    sub = ()=>{
        this.setState((prevstate)=>{
            return{
                count:prevstate.count-1
            }
        })
    }
    reset=()=>{
        this.setState((prevstate)=>{
            return{
                count:10
            }
        })
    }
    render(){
        
        return(
            <div>
                <p>The current state is {this.state.count}</p>
                <button onClick={this.add}>Add</button>
                 <button onClick={this.sub}>Sub</button>
                 <button onClick={this.reset}>Reset</button>
            </div>
        )
    }
}
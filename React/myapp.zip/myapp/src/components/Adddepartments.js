import {Component} from 'react';

export default class Adddepartments extends Component{
    //data =[]
    addDept=(e)=>{
        e.preventDefault()
        const data = e.target.elements.udept.value
        
        //alert(data)
        //document.getElementById("name").innerHTML=name
        //document.getElementById("email").innerHTML=email
        //document.getElementById("city").innerHTML=city
        this.props.adddpt(data)

       
    }
    render(){
        return(
            <div>
               
                <form onSubmit={this.addDept}>
                   Department: <input type="text" name='udept'></input><br></br>
                   
                <button >Add Dept</button>
                </form>
                
            </div>
        )
    }}

//import {Component} from 'react';


 function Option(props){
  const delUser=()=>{
        props.del(props.mydata.name)
    }
    
     return(
            <div>
            
               <div>
            
                    {props.mydata.name}
                    <button onClick={delUser}> delete</button>
                    </div>
                    
             <div>
            
                    {props.mydept}
                    </div>
                
            </div>
        )
    }
export default Option
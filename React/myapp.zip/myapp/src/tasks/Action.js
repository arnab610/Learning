
import {Component} from 'react';

//export default class Action extends Component{
    function Action(props){
    //render(){
        return(
            <div>
                <h3> Welcome toAction </h3>
                <button disabled={!props.isData}>Show Action</button>
                <button disabled={!props.isDat}>Show Dept</button>
            </div>
        )
    }
export default Action
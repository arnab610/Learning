
import {Component, useState} from 'react';
import Action from './Action';
import Adddepartments from './Adddepartments';
import AddOption from './AddOption';
import Counter from './Counter';
import Footer from './Footer';
import Header from './Header';
import Options from './Options';

//export default class MainApp extends Component{
    function MainApp(){
  /*  state={
         userdata :[],
         departments:[]

    }*/
    const [userdata, setUserdata]= useState([])
    const [departments, setDepartment]= useState([])
    const emptyUserArray=()=>{
        /*this.setState(()=>{
            return{
                userdata:[]
            }
        })*/
        setUserdata([])
    }
  const  emptyDeptArray=()=>{
      /*  this.setState(()=>{
            return{
                departments:[]
            }
        })*/
        setDepartment([])
    }

   const addUser=(data)=>{
        /*this.setState((prevstate)=>{
            return{
                userdata:prevstate.userdata.concat(data)
            }
        })*/
        setUserdata([
            ...userdata,{name:data}
        ])
    }
   const addDept=(data)=>{
        /*this.setState((prevstate)=>{
            return{
                departments:prevstate.departments.concat(data)
            }
        })*/
        setDepartment([
            ...departments,{data}
        ])
    }
    const deleteUser=(data)=>{
        /*this.setState((prevState)=>{
            return{
            userdata:prevState.userdata.filter((input)=> data !==input)
            }
        })*/
        setUserdata(userdata.filter((user)=> user.name !== data))
    }

    



    
        
        return(
            <div>
                <Header hmessage="Welcome to HEader"/>
                <h3> Welcome to Main App</h3>
                
                
                
                <Options udata={userdata} udept={departments} eu={emptyUserArray}
                 ed={emptyDeptArray} du={deleteUser}/>
                <Action isData={userdata.length>0} isDat={departments.length>0}/>
            
                <AddOption aomsg="WElcome to add Option" addusr={addUser} />
                <Adddepartments adddpt={addDept} />
                <Counter/>
                <Footer />
            </div>
        )
    }
    export default MainApp

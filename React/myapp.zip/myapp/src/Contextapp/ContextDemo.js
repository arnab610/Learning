import { createContext, useState, useContext} from "react"

const empContext = createContext()
function ContextDemo(props){

    const [employee, setEmployee]= useState({id:101,name:'admin',location:'banglore',salary:12345})
    return(
        <div>
            <empContext.Provider value={employee}>
            <Employee/>
            </empContext.Provider>
            
        </div>
    )
}
function Employee(props){
    let context= useContext(empContext)
    return(
        <div>
            <h3>Welcome to Employee </h3>
            NAme:{context.name}
            <br></br>
            location:{context.location}
            
            <br/>
            
            <Salary/>
        </div>
    )
}
function Salary(props){
    let context= useContext(empContext)
    return(
        <div>
            <h3>Welcome to Salary </h3>
            Salary:{context.salary}
        </div>
    )
}
export default ContextDemo
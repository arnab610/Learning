const Table=(props)=> {
    
    
      return (
 
          <div>
            

<div className="container">
        {props.v.map((d)=>{
          return(
            
            <div>
             <table  className="table" border="1"> 
                 <tr>
                     <th>Name</th>
                     <th>Email</th>
                    
                 </tr>
                 <tr>
                
                <td><h3>{d.name}  </h3></td> 
                 <td><h3>{d.email}</h3></td> 
                
                 </tr>
                 </table>
               </div>)
           
          
          
          
        })}
      </div>


          </div>
        
      );
    }
    
    export default Table;
    
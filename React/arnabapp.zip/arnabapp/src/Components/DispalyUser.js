import React, { useEffect, useState } from 'react'
import Table from './table'

const WedApp = () => {
  const [data, setData] = useState(null)
  const [val, setValue]=useState([])

  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [dept, setDept] = useState('')

  const add=(name)=>{
   // console.log(name)
   var  x=(data.filter((note)=> note.name == name))
   console.log(x[0].name)
    setValue(
      [...val,{name:x[0].name,email:x[0].email}
      ])
    console.log(val)


  }
  const fetchURL = "https://jsonplaceholder.typicode.com"
  const getData = () =>
    fetch(`${fetchURL}/users`)
      .then((res) => res.json())

  useEffect(() => {
    getData().then((data) => setData(data))
  }, [])

  return (
    <div>
      {data?.map((item) => 
        <div className="card">
        <div className="card-body"> 
        <hr/>
 <h5 className="card-title">{item.name}</h5>
 <h6 className="card-title">{item.email}</h6>
 <button onClick={ ()=>add(item.name)}>Add To Cart</button>

 
        </div> 
     </div>
      )}

     <Table v={val}/>
    </div>
  )
}

export default WedApp;
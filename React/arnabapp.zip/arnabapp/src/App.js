import logo from './logo.svg';
import './App.css';
import axios from 'axios'
import DisplayUsers from './Components/DispalyUser';
function App() {


  return (
    <div className="App">
     <DisplayUsers/>
      
    </div>
  );
}

export default App;

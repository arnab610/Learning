package com.service;

import com.model.interestCalculator;

public class CalculatorService {
	private interestCalculator ic;
	
	
	
	public interestCalculator getIc() {
		return ic;
	}



	public void setIc(interestCalculator ic) {
		this.ic = ic;
	}



	public CalculatorService() {
		System.out.println("CS is initilised");
	}



	public double service(double amount) {
		return ic.calculate(amount);
	}
	
	public void callInit() {
		
		System.out.println("init is called");
		
	}
public void callDestroy() {
		
		System.out.println("destroy is called");
		
	}
}

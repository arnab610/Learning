package com.model;

public interface interestCalculator {
	public double calculate(double amount);

}

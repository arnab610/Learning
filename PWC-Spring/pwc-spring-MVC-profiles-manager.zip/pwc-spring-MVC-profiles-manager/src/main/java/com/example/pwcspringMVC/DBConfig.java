package com.example.pwcspringMVC;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
@Configuration
@ConfigurationProperties("spring.user")
public class DBConfig {
	
	private String name;
	private String email;
	private String city;
	private int pincode;
	
	
	/*public DBConfig() {
		super();
		// TODO Auto-generated constructor stub
	}*/
	
	
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	@Bean
	@Profile("manger")
	public String devDBLoad() {
		System.out.println("Manager with  profile loaded");
		System.out.println(name);
		System.out.println(email);
		System.out.println(city);
		System.out.println(pincode);
		return "DB MAnager Environment loaded";
	}
	
	@Bean
	@Profile("fin")
	public String testDBLoad() {
		System.out.println("Fin profile loaded");
		System.out.println(name);
		System.out.println(email);
		System.out.println(city);
		System.out.println(pincode);
		return "DB Fin Environment loaded";
	}
	
	@Bean
	@Profile("qa")
	public String prodDBLoad() {
		System.out.println("DB with Qa profile loaded");
		System.out.println(name);
		System.out.println(email);
		System.out.println(city);
		System.out.println(pincode);
		return "DB Qa Environment loaded";
	}
		
	

}

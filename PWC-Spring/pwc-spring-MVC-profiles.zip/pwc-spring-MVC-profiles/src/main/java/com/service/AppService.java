package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.model.Login;
import com.model.Register;

@Service
public class AppService {
	
	RestTemplate template = new RestTemplate();
	public String callApp() {
		String response = template.exchange("http://localhost:8090/mainapp/welcome",
				HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {
				}).getBody();
		return response;
	}
	
	public String callAppOrm() {
		String response = template.exchange("http://localhost:8060/mainapp/welcome",
				HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {
				}).getBody();
		return response;
	}
	
}

package com.example.pwcspring;

public class Greetimpl implements Welcome {

	@Override
	public void Greet(String name) {
		// TODO Auto-generated method stub
		System.out.println(name+ "welcome to Aop");
		
	}

}

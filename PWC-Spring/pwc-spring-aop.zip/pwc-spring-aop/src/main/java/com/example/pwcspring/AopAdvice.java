package com.example.pwcspring;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;



@Component
@Aspect


public class AopAdvice{
	@Before(value = "execution(* com.example.pwcspring.Greetimpl.Greet(..))")
	public void callBefore() {
		System.out.println("Calling before");
	}

}

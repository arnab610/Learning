package com.example.pwcspring;

public interface EmployeeDao {
	public void insertEmployee(Employee employee);

}

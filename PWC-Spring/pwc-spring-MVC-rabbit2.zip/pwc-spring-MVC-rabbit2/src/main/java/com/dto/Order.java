package com.dto;

public class Order {
	private String bookingid;
	private int noofpax;
	private String cuisine;
	private int starratting;
	public String getBookingid() {
		return bookingid;
	}
	public void setBookingid(String bookingid) {
		this.bookingid = bookingid;
	}
	public int getNoofpax() {
		return noofpax;
	}
	public void setNoofpax(int noofpax) {
		this.noofpax = noofpax;
	}
	public String getCuisine() {
		return cuisine;
	}
	public void setCuisine(String cuisine) {
		this.cuisine = cuisine;
	}
	public int getStarratting() {
		return starratting;
	}
	public void setStarratting(int starratting) {
		this.starratting = starratting;
	}
	public Order(String bookingid, int noofpax, String cuisine, int starratting) {
		super();
		this.bookingid = bookingid;
		this.noofpax = noofpax;
		this.cuisine = cuisine;
		this.starratting = starratting;
	}
	@Override
	public String toString() {
		return "Order [bookingid=" + bookingid + ", noofpax=" + noofpax + ", cuisine=" + cuisine + ", starratting="
				+ starratting + "]";
	}


}

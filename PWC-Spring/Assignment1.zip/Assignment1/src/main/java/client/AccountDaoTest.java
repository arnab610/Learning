/**
 * 
 */
package client;


import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.entity.Account;



public class AccountDaoTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	 // ApplicationContext context  = 
			  	//new ClassPathXmlApplicationContext("beans.xml");
		ConfigurableApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		//AccountRepository accountRepository = (AccountRepository) ctx.getBean("rahulAccount");
	  
	  Account rahulAcc = 
			 (Account) ctx.getBean("rahulAccount");
	 System.out.println(rahulAcc.getAccountNumber() 
			 		+"," + rahulAcc.getAccountOwner() 
			 		+"," + rahulAcc.getBalance());
	}

}

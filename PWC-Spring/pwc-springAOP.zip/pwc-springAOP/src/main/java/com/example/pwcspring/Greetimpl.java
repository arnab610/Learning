package com.example.pwcspring;

import org.springframework.stereotype.Component;

@Component("gi")
public class Greetimpl implements Welcome {

	@Override
	public void Greet(String name) {
		// TODO Auto-generated method stub
		System.out.println(name+ " welcome to Aop");
		
	}

	@Override
	public void sayHello(String name, String city) {
		// TODO Auto-generated method stub
		System.out.println(name+" "+ city);
	}

}

package com.example.pwcspring;

public interface Welcome {
public void Greet(String name);
public void sayHello(String name, String city);
}

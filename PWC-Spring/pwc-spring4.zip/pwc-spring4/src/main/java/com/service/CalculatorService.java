package com.service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.model.interestCalculator;

@Lazy
public class CalculatorService {
	
	private interestCalculator ic;
	
	
	
	public interestCalculator getIc() {
		return ic;
	}
	



	public void setIc(interestCalculator ic) {
		this.ic = ic;
	}



	public CalculatorService() {
		System.out.println("CS is initilised");
	}
	



	public CalculatorService(interestCalculator ic) {
		super();
		this.ic = ic;
	}




	public double service(double amount) {
		return ic.calculate(amount);
	}
	@PostConstruct
	
	public void callInit() {
		
		System.out.println("init is called");
		
	}
	@PreDestroy
public void callDestroy() {
		
		System.out.println("destroy is called");
		
	}
}

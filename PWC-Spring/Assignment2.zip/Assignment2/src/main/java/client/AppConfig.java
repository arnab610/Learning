package client;

public class AppConfig {

}

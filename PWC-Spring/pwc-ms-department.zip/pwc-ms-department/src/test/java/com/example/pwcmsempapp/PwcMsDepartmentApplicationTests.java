package com.example.pwcmsempapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PwcMsDepartmentApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.model;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@ApiModel(description="detials about Dept")

public class Department {
	@ApiModelProperty(notes="Department name")
	private String departmentname;
	@ApiModelProperty(notes="Department managername")
	private String mangername;
	public Department(String departmentname, String mangername) {
		super();
		this.departmentname = departmentname;
		this.mangername = mangername;
	}
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Department [departmentname=" + departmentname + ", mangername=" + mangername + "]";
	}
	public String getDepartmentname() {
		return departmentname;
	}
	public void setDepartmentname(String departmentname) {
		this.departmentname = departmentname;
	}
	public String getMangername() {
		return mangername;
	}
	public void setMangername(String mangername) {
		this.mangername = mangername;
	}
	

}

package com.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.model.Department;


import io.swagger.annotations.ApiOperation;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DeptController {

	private static Map<String, List<Department>> empDB=new HashMap<String, List<Department>>();
	static List<Department> lst=new ArrayList<Department>();
	static {
		empDB=new HashMap<String,List<Department>>();
		
		Department emp=new Department("IT","Arnab");
		lst.add(emp);
		emp=new Department("CS","Mitesh");
		lst.add(emp);
		empDB.put("ABC", lst);
		
		lst=new ArrayList<Department>();
		emp=new Department("MECH","Sandeep");
		lst.add(emp);
		emp=new Department("ELECT","Sam");
		lst.add(emp);
		empDB.put("DEF", lst);
	}
	@GetMapping("/loaddept/{pro}")
	
	public List<Department> loaddep(@PathVariable("pro")String pro){
		List<Department> emplist=empDB.get(pro);
		if(emplist == null) {
			emplist=new ArrayList<Department>();
			Department emp=new Department("NA","NOT FOUND");
			emplist.add(emp);
		}
		
		return emplist;
	}
	@ApiOperation(value="load all depet from backend",
			notes="basically loads stored ata from mysql databsse", response=Department.class)
	@GetMapping("/loaddept")
	public List<Department> loaddep(){
		return lst;
	}
	
}

package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="spring_regstudent")
public class Register {
	@Id
	@GeneratedValue
	private int roll;
	private String stuname;
	private String subject;
	private int marks;
	public int getRoll() {
		return roll;
	}
	public void setRoll(int roll) {
		this.roll = roll;
	}
	public String getStuname() {
		return stuname;
	}
	public void setStuname(String stuname) {
		this.stuname = stuname;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public Register(int roll, String stuname, String subject, int marks) {
		super();
		this.roll = roll;
		this.stuname = stuname;
		this.subject = subject;
		this.marks = marks;
	}
	public Register() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Register [roll=" + roll + ", stuname=" + stuname + ", subject=" + subject + ", marks=" + marks + "]";
	}
	
}
	


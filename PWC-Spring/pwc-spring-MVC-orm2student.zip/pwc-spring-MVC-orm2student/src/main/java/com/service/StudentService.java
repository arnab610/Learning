package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.AppDao;
import com.model.Login;
import com.model.Register;



@Service

public class StudentService {
	
	@Autowired
	private AppDao appDao;
	ArrayList <Register> lst=new ArrayList<Register>();

			
	

public void adduser(Register reg) {
	//lst.add(reg);
	appDao.save(reg);
	System.out.println(lst);
}
public List<Register> loadAll() {
	List<Register> lst = (List<Register>)appDao.findAll();
	return lst;
	
}

public boolean findUser(Integer id) {
	Optional opt = appDao.findById(id);
	if(opt.isPresent()) {
		return true;
	}
	
	return false;
	
	
}

public boolean deleteUser(Integer id) {
	Optional opt = appDao.findById(id);
	if(opt.isPresent()) {
		appDao.deleteById(id);
		return true;
	}
	return false;
	
	
}
public void updateUser(Register reg,int id) {
	
	

	
		
		Optional opt = appDao.findById(id);
		if(opt.isPresent()) {
			appDao.deleteById(id);
			appDao.save(reg);
		
		
		
	}
}

	
	
	
}



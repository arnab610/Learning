package com.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;

public class EmployeeLambdaGateway implements RequestHandler<Object, EmployeeLambda>{

	@Override
	public EmployeeLambda handleRequest(Object input, Context context) {
		// TODO Auto-generated method stub
		EmployeeLambda res = new EmployeeLambda(1, "arnab", "bls", "a@gmail.com");
		System.out.println(res);
		return res;
	}

}

package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.model.Login;
import com.model.Register;

@Service
public class AppService {
	
	List<Register> lst = new ArrayList<Register>();
 public boolean loginValid(Login login) {
	// if(login.getUserName().equals("admin") && login.getPassword().equals("manager")) {
			//return true;
		//}
		//return false;
	 for(Register r:lst) {
		 if(r.getUserName().equals(login.getUserName()) && r.getPassword().equals(login.getPassword())) {
			 return true;
		 }
		
	 }
	 return false;
	 
 }
 
 public void addUser(Register registration) {
	 lst.add(registration);
	 System.out.println(lst);
 }
 public List<Register> loadAll(){
	 return lst;
 }
 public boolean findUser(String name) {
	 for(Register rs: lst) {
		 if(rs.getUserName().equals(name)) {
		 System.out.println(rs.getEmail());
		 return true;
		 }
	 }
	 return false;
 }
 
 public boolean deleteUser(String name) {
	 for(Register rs: lst) {
		 if(rs.getUserName().equals(name)) {
		 lst.remove(rs);
		 return true;
		 }
	 }
	 return false;
 }
 public void updateUser(Register reg, String name) {
	 
	 for(Register rs: lst) {
		 if(rs.getUserName().equals(name)) {
			 rs.setUserName(reg.getUserName());
			 rs.setPassword(reg.getPassword());
			 rs.setEmail(reg.getEmail());
			 rs.setCity(reg.getCity());
		 }
		
		 
		 }
	 
	 
	 
 }
}

package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Login;
import com.model.Register;
import com.service.AppService;

@RestController
@RequestMapping("/mainapp")
public class AppController {
	@Autowired
	private AppService service;
	//@RequestMapping(value="/welcome", method =RequestMethod.GET)
	@GetMapping("/welcome")
	//@ResponseBody
	public List<Register> sayHello() {
		List<Register> lst = service.loadAll();
		return lst;
	}
	//@RequestMapping(value="/login", method =RequestMethod.POST)
	@PostMapping("/login")
	//@ResponseBody
	public String login(@RequestBody Login login) {
		if(service.loginValid(login)) {
			return "login success";
		}
		return "Login Failure";
		
	}
	//@RequestMapping(value="/register", method =RequestMethod.POST)
	@PostMapping("/register")
	//@ResponseBody
	public String register(@RequestBody Register reg) {
		service.addUser(reg);
		return "Registered";
	}
	
	@GetMapping("/finduser/{uname}")
	
	public String findUser(@PathVariable("uname")String name) {
		if(service.findUser(name)) {
			return name+" found";
		}
		return "Not found";
		
	}
@DeleteMapping("/deleteuser/{uname}")
	
	public String deleteUser(@PathVariable("uname")String name) {
		if(service.deleteUser(name)) {
			return name+" deleted";
		}
		return "Not found";
		
	}
@PutMapping("/updateuser/{uname}")
public String updateUser(@RequestBody Register reg,@PathVariable("uname")String name ) {
	service.updateUser(reg, name);
	return "Updated";
	
}





}

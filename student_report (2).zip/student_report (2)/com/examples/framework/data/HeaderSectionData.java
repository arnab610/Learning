package com.examples.framework.data;

public class HeaderSectionData {
	// Report Title, Banner Text
	public String title ="";
}

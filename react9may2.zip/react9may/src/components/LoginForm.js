import React, { useState, useEffect } from "react";
import { Modal, Button, FormControl, FormGroup } from "react-bootstrap";
import Form from "react-bootstrap/Form";
import { useHistory } from "react-router-dom";
import UserService from "../services/UserService";

const LoginForm = (props) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [users, setUsers] = useState([])
    const [t, setT] = useState('');
    var history = useHistory();
    const init = () => {
        UserService.getAll()
          .then(response => {
            console.log('Printing Movies data', response.data);
            setUsers(response.data);
          })
          .catch(error => {
            console.log('Something went wrong', error);
          }) 


      }
    
      useEffect(() => {
        init();
      }, []);
  const verifyData = () => {
    var ans = users.filter((d) => {
        if(d.email == email && d.password == password) {
            sessionStorage.setItem('id', d.id);
            console.log("d value"+d)
            return d;
        } else {
            return null;
        }
    })
    if(ans.length>0) {
      console.log("ans "+ans)
        history.push('/user')
    } else {
      console.log("else")
        alert('Not')
        history.push('/')
    }
  };
  return (
    <div>
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            <h3 style={{ color: "#000080" }}>Welcome back user !</h3>
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                placeholder="name@example.com"
                id="email"
                onChange={(e) => setEmail(e.target.value)}
                autoFocus

              />
            </Form.Group>

            <Form.Group className="mb-3" controlId="exampleForm.ControlInput2">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" placeholder="*******" 
              onChange={(e) => setPassword(e.target.value)}
              autoFocus />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={verifyData}>
            LOGIN
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default LoginForm;

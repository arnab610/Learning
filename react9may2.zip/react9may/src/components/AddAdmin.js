import { useState } from "react";
import { Link, useHistory, useParams } from "react-router-dom";
import { useEffect } from "react"
import AdminService from '../services/Service';

const AddAdmin = () => {
   
    const[email, setEmail] = useState('');
    const[password, setPassword] = useState('')






    const history = useHistory();
 

    const saveAdmin = (e) => {
        e.preventDefault();
        const admin = {email, password};
        // if (id) {
        //     //update
        //     adminService.update(employee)
        //         .then(response => {
        //             console.log('Employee data updated successfully', response.data);
        //             history.push('/');
        //         })
        //         .catch(error => {
        //             console.log('Something went wrong', error);
        //         }) 
        // } else {
            //create
            AdminService.create(admin)
            // var id= response.data.id;
            // sessionStorage.setItem('id', response.data.id);
            // history.push("/");
            .then(response => {
                console.log("Admin added added successfully", response.data);
                
               // console.log(response.data.id)
                sessionStorage.setItem('aid', response.data.id);
                console.log("add admin"+sessionStorage.getItem('aid'));
               
                history.push("/admin");
            })
            .catch(error => {
                console.log('something went wrong', error);
            })
        }
    

    return(
        <div className="container">
            <h3>Add Admin</h3>
            <hr></hr>
          <Link to="/application">Back to Home</Link>
            <hr/>
            <form>
                <div className="form-group">
                    <input 
                        type="email" 
                        className="form-control col-4"
                        id="name"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter mail id"
                    />

                </div>
                <div className="form-group">
                    <input 
                        type="password" 
                        className="form-control col-4"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter password"
                    />

                </div>

                <div >
                    <button onClick={(e) => saveAdmin(e)} className="btn btn-primary">Save</button>
                </div>
            </form>
            
        </div>
    )
    }

export default AddAdmin;
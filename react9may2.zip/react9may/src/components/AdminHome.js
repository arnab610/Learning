import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import AdminService from '../services/Service';
import dateFormat from 'dateformat';

const AdminHome = () => {

  const [movies, setMovies] = useState([]);
  const [adminid, setadminId] = useState(-1);

  const init = () => {
    AdminService.getAllMovies()
      .then(response => {
        console.log('Printing Movies data', response.data);
        setMovies(response.data);
      })
      .catch(error => {
        console.log('Something went wrong', error);
      }) 
      setadminId(sessionStorage.getItem('aid'));
      console.log("init"+adminid);
  }

  useEffect(() => {
    init();
  }, []);

  const handleDelete = (id) => {

    if(window.confirm("Do you want to delete")) {
      console.log('Printing id', id);
      AdminService.removeMovie(id)
        .then(response => {
          console.log('movie deleted successfully', response.data);
          init();
        })
        .catch(error => {
          console.log('Something went wrong', error);
        })
    }
  }



  return (
    
    <div className="container">
     {console.log("return"+adminid)}
      <h3>List of Movies</h3>
      <hr/>
      <div>
        <Link to="/add" className="btn btn-primary mb-2 mx-4">Add Movie</Link>

        <Link to="/adminfeedback" className="btn btn-primary mb-2">FEEDBACK</Link>
        <table className="table table-bordered table-striped">
          <thead className="thead-dark">
            <tr>
              <th>Image</th>
              <th>Name</th>
              <th>Description</th>
              <th>Date</th>
              <th>Silver Seats</th>
              <th>Gold Seats</th>
              <th>Platinum Seats</th>
              <th>Discount</th>
              <th>Price</th>
              <th>Update</th>
              <th>Delete</th>
            </tr>
          </thead>
          <tbody>
          {movies.filter((n)=>{
            console.log(n)
             if(adminid == "") {
              return n;
          } else if(n.adminId == adminid) {
              return n;
          }

          }).map((movie) => (
            
              <tr key={movie.id}>
                <td><img src={movie.img} alt={movie.movName} width="40px"/></td>
                <td>{movie.movName}</td>
                <td>{movie.description}</td>
                <td>{dateFormat(movie.date, 'mm/dd/yyyy')}</td>
                <td>{movie.silverSeat}</td>
                <td>{movie.goldSeat}</td>
                <td>{movie.platinumSeat}</td>
                <td>{movie.discount}</td>
                <td>{movie.price}</td>

                <td>
                  <Link className="btn btn-info" to={`/movies/edit/${movie.id}`}>Update</Link>
                  
                </td>
                <td>                  
                  <button className="btn btn-danger ml-2" onClick={() => {
                    handleDelete(movie.id);
                  }}>Delete</button></td>
              </tr>
            ))
          }
          </tbody>
        </table>
        
      </div>
    </div>
  );
}

export default AdminHome

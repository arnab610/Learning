import FeedbackService from "../services/FeedbackService";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

const Userfeedbackdisplay = () => {
    const [userFeedback, setUserFeedback] = useState([]);

    const init = () => {
      FeedbackService.getAll()
        .then(response => {
          console.log('Printing Movies data', response.data);
          setUserFeedback(response.data);
        })
        .catch(error => {
          console.log('Something went wrong', error);
        }) 
    }
  
    useEffect(() => {
      init();
    }, []);
    return (
        <div className="container">
          <h3>List of User Feedbacks</h3>
          <hr></hr>
          <Link to="/application">Back to Home</Link>
          <hr/>
          <div>
            <table className="table table-bordered table-striped">
              <thead className="thead-dark">
                <tr>
                  <th>Name</th>
                  <th>Movie Name</th>
                  <th>Rating</th>
                  <th>Feedback</th>

                </tr>
              </thead>
              <tbody>
              {
                userFeedback.map(f => (
                
                  <tr key={f.id}>
                      <td>{f.userName}</td>
                    <td>{f.movie}</td>
                    <td>{f.noofStars}</td>
                    <td>{f.feedback}</td>
                  </tr>
                ))
              }
              </tbody>
            </table>
            
          </div>
        </div>

      );
}

export default Userfeedbackdisplay;
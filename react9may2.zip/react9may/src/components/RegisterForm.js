import React, { useState } from "react";
import { Modal, Button, FormControl, FormGroup } from "react-bootstrap";
import Form from "react-bootstrap/Form";
import UserService from "../services/UserService";
import { useHistory } from "react-router";
import {ReactSession} from "react-client-session";

export const RegisterForm = (props) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const history = useHistory();
  const saveData = (e) => {
      e.preventDefault();
      var u = {email,password};
    UserService.create(u)
    .then(response => {
        console.log("User added added successfully", response.data);
        var id= response.data.id;
        sessionStorage.setItem('id', response.data.id);
        history.push("/user");
    })
    .catch(error => {
        console.log('something went wroing', error);
    })
  };
  return (
    <div>
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header closeButton>
          <Modal.Title id="contained-modal-title-vcenter">
            <h3 style={{ color: "#000080" }}>Welcome User !</h3>
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput1">
              <Form.Label>Email address</Form.Label>
              <Form.Control
                type="email"
                placeholder="name@example.com"
                autoFocus
                id="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </Form.Group>
            <Form.Group className="mb-3" controlId="exampleForm.ControlInput2">
              <Form.Label>Password</Form.Label>
              <Form.Control type="password" placeholder="*******" 
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoFocus />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="primary" onClick={(e) => saveData(e)}>
            REGISTER
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

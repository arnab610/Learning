import React, { useState } from "react";
import "../css/Login.css";
import { Button, Modal } from "react-bootstrap";
import LoginForm from "./LoginForm";
import { RegisterForm } from "./RegisterForm";

const Login = () => {
  const [loginModalShow, setLoginModalShow] = useState(false);
  const [registerModalShow, setRegisterModalShow] = useState(false);
  return (
    <div className="maindiv">
      <header>
        <img src={require("./Capture.PNG")} id="myimage"></img>
        <nav>
          <ul>
            <li>
              <a href="#">ABOUT</a>
            </li>
            <li>
              <a href="#">CONTACT US</a>
            </li>
            <li>
              <a>
                <Button
                  variant="outline-success"
                  className="buttons"
                  style={{
                    border: "1px solid #93e9be",
                  }}
                  onClick={() => setLoginModalShow(true)}
                >
                  Sign In
                </Button>{" "}
              </a>
            </li>
            <li>
              <Button
                id="outline-button"
                variant="outline-success"
                style={{
                  border: "1px solid #93e9be",
                }}
                className="buttons"
                onClick={() => setRegisterModalShow(true)}
              >
                Sign Up
              </Button>{" "}
            </li>
          </ul>
        </nav>
      </header>
      <main>
        <div id="introdiv">
          TICKET BOOKING
          <br /> FOR <span>MOVIE</span>
          <br></br>
          <img src={require("./ticket.PNG")}></img>
        </div>
      </main>
      <LoginForm
        show={loginModalShow}
        onHide={() => setLoginModalShow(false)}
      />
      <RegisterForm
        show={registerModalShow}
        onHide={() => setRegisterModalShow(false)}
      />
    </div>
  );
};

export default Login;

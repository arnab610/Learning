import { useState, useEffect } from "react";
import { Link, useHistory, useParams } from "react-router-dom";
import AdminService from '../services/Service';

const Addmovie = () => {
    const[movName, setName] = useState('');
    const[description, setDescription] = useState('');
    const[multiplex, setMultiplex] = useState('');
    const[time, setTime] = useState(null);
    const[silverSeat, setSilverSeat] = useState(0);
    const[goldSeat, setGoldSeat] = useState(0);
    const[platinumSeat, setPlatinumSeat] = useState(0);
    const[price, setPrice] = useState(0);
    const [discount, setDiscount] = useState(0);
    const[date, setDate] = useState(null);
    const[img, setImg] = useState('');
    const history = useHistory();
    const {id} = useParams();

    const savemovie = (e) => {
        e.preventDefault();
        console.log("add movie"+sessionStorage.getItem('aid'))
        
        const movie = {id:id,adminId:parseInt(sessionStorage.getItem('aid')) ,movName:movName,description:description,multiplex: multiplex, img:img,date: date, time:time,silverSeat: silverSeat,goldSeat: goldSeat, platinumSeat:platinumSeat,  discount:discount, price:price};
        if (id) {
            //update
            AdminService.updateMovie(movie)
                .then(response => {
                    console.log('movie data updated successfully', response.data);
                    history.push('/admin');
                })
                .catch(error => {
                    console.log('Something went wrong', error);
                }) 
        } else {
            //create
            AdminService.createMovie(movie)
            .then(response => {
                console.log("movie added successfully", response.data);
                history.push("/admin");
            })
            .catch(error => {
                console.log('something went wroing', error);
            })
        }
    }

    useEffect(() => {
        if (id) {
            AdminService.getMovie(id)
                .then(movie => {
                    setName(movie.data.movName);
                    setDescription(movie.data.description);
                    setMultiplex(movie.data.multiplex);
                    setTime(movie.data.time);
                    setDate(movie.data.date);
                    setImg(movie.data.img);
                    setSilverSeat(movie.data.silverSeat);
                    setGoldSeat(movie.data.goldSeat);
                    setPlatinumSeat(movie.data.platinumSeat);
                    setDiscount(movie.data.discount);
                    setPrice(movie.data.price);
                    
                })
                .catch(error => {
                    console.log('Something went wrong', error);
                })
        }
    }, [])
    return(
        <div className="container">
            <h3>Add Movie</h3>
            <hr/>
            <form>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="movName"
                        value={movName}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Enter movie name"
                    />

                </div>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="description"
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="Enter description"
                    />

                </div>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="multiplex"
                        value={multiplex}
                        onChange={(e) => setMultiplex(e.target.value)}
                        placeholder="Enter multiplex"
                    />
                    
                </div>

                <div className="form-group">
                    <input 
                        type="number" 
                        className="form-control col-4"
                        id="silverSeat"
                        value={silverSeat}
                        onChange={(e) => setSilverSeat(e.target.value)}
                        placeholder="Enter number of Silver seat"
                    />
                    
                </div>
                <div className="form-group">
                    <input 
                        type="number" 
                        className="form-control col-4"
                        id="goldSeat"
                        value={goldSeat}
                        onChange={(e) => setGoldSeat(e.target.value)}
                        placeholder="Enter number of Gold seat"
                    />
                    
                </div>
                <div className="form-group">
                    <input 
                        type="number" 
                        className="form-control col-4"
                        id="platinumSeat"
                        value={platinumSeat}
                        onChange={(e) => setPlatinumSeat(e.target.value)}
                        placeholder="Enter number of Platinum seat"
                    />
                    
                </div>
                <div className="form-group">
                    <input 
                        type="number" 
                        className="form-control col-4"
                        id="discount"
                        value={discount}
                        onChange={(e) => setDiscount(e.target.value)}
                        placeholder="Enter discount"
                    />
                    
                </div>
                <div className="form-group">
                    <input 
                        type="number" 
                        className="form-control col-4"
                        id="price"
                        value={price}
                        onChange={(e) => setPrice(e.target.value)}
                        placeholder="Enter Price"
                    />
                    
                </div>
                
                <div className="form-group">
                    <input 
                        type="time" 
                        className="form-control col-4"
                        id="date"
                        value={date}
                        onChange={(e) => setDate(e.target.value)}
                        placeholder="Enter Time"
                    />
                    
                </div>
                <div className="form-group">
                    <input 
                        type="text" 
                        className="form-control col-4"
                        id="img"
                        value={img}
                        onChange={(e) => setImg(e.target.value)}
                        placeholder="Enter Image url"
                    />
                    
                </div>
                <div >
                    <button onClick={(e) => savemovie(e)} className="btn btn-primary">Save</button>
                </div>
            </form>
            <hr/>
            <Link to="/admin">Back to List</Link>
        </div>
    )
}

export default Addmovie;
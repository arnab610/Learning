import { useEffect, useState } from "react";
import { useHistory, useParams, Link } from "react-router-dom";
import FeedbackService from "../services/FeedbackService";

const Userfeedback = () => {
    const [username, setUsername] = useState('')
    const [movie, setMovie] = useState('')
    const [rating, setRating] = useState(5);
    const [feedback, setFeedback] = useState('Good');
    const history = useHistory();
    const id = useParams();
    const submitFeedback =(e) => {
        e.preventDefault()
        var r = parseInt(rating)
        var feed = {userName: username, movie: movie, noofStars: r, feedback: feedback}
        console.log(feed)
        FeedbackService.create(feed)
        .then(response => {
            alert('Thank You For Feedback')
            console.log("Feedback ", response.data);
            history.push("/user");
        })
        .catch(error => {
            console.log('something went wroing', error);
        })
    }
    useEffect(() => {
        var {name} = id
        setMovie(name);
        //console.log(name);
    }, [])
    return (
        <div>

            <div class="card" style={{width:"18rem"}}>
                <div class="card-body">
                        <h5 class="card-title">Your Feedback</h5>
                        <hr></hr>
                        <Link to="/user">Back to Home</Link>
                        <hr></hr>
                        <form>
                        <div class="mb-3">
                            <label for="username" class="form-label">User Name</label>
                            <input 
                                type="text" 
                                class="form-control" 
                                id="username" 
                                value={username}
                                onChange={(e) => setUsername(e.target.value)}
                                />
                        </div>
                        <div class="mb-3">
                            <label for="customRange1" class="form-label">Rating</label>
                            <input 
                                type="number" 
                                class="form-control"  
                                id="customRange1" 
                                min="0" 
                                max="5" 
                                value={rating}
                                onChange={(e) => setRating(e.target.value)}/>
                        </div>
                        <div class="mb-3 ">
                            <label for="floatingTextarea">Feedback</label>
                            <input 
                                type="text" 
                                className="form-control"
                                id="feedback"
                                value={feedback}
                                onChange={(e) => setFeedback(e.target.value)}
                                placeholder="Enter description"
                            />
                        </div>
                        <button type="submit" onClick={(e) => submitFeedback(e)} class="btn btn-primary">Submit</button>
                        </form>
                </div>
            </div>
            
        </div>
    );
}

export default Userfeedback;
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useHistory } from "react-router-dom";
import AdminService from '../services/Service';

const AdminLogin = (props) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [admins, setAdmins] = useState([])
    const [t, setT] = useState('');
    var history = useHistory();
    const init = () => {
        AdminService.getAll()
          .then(response => {
            console.log('Printing admin data', response.data);
            setAdmins(response.data);
          })
          .catch(error => {
            console.log('Something went wrong', error);
          }) 


      }
    
      useEffect(() => {
        init();
      }, []);
  const verifyData = () => {
    var ans = admins.filter((d) => {
        if(d.email == email && d.password == password) {
            sessionStorage.setItem('aid', d.id);
            console.log("d value"+d)
            return d;
        } else {
            return null;
        }
    })
    if(ans.length>0) {
      console.log("ans "+ans)
        history.push('/admin')
    } else {
      console.log("else")
        alert('Not')
        history.push('/')
    }
  };
  return (
  
    <div className="container">
            <h3>Admin Login</h3>
            <hr></hr>
          <Link to="/application">Back to Home</Link>
            <hr/>
            <form>
                <div className="form-group">
                    <input 
                        type="email" 
                        className="form-control col-4"
                        id="name"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="Enter mail id"
                    />

                </div>
                <div className="form-group">
                    <input 
                        type="password" 
                        className="form-control col-4"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter password"
                    />

                </div>

                <div >
                    <button onClick={(e) => verifyData(e)} className="btn btn-primary">Login</button>
                </div>
            </form>
            
        </div>
  
    );
}
export default AdminLogin;

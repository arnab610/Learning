import {NavLink, Link} from "react-router-dom"

const ApplicationManager = () => {
    return (
        <div>
           <nav class="navbar navbar-expand-lg navbar-light bg-light">
       <div class="container-fluid">
       <Link to="/application" className="btn btn-primary mb-2 mx-4">Home</Link>
         <div class="collapse navbar-collapse" id="navbarNavDropdown">
           <ul class="navbar-nav">
             <li class="nav-item">
             <Link to="/userfeedbackdisplay" className="btn btn-primary mb-2 mx-4">USER FEEDBACK</Link>
             </li>

             <li class="nav-item">
             <Link to="/adminfeedbackdisplay" className="btn btn-primary mb-2 mx-4">ADMIN FEEDBACK</Link>
             </li>

             <li class="nav-item">
             <Link to="/addadmins" className="btn btn-primary mb-2 mx-4">ADD ADMIN</Link>
             </li>
           </ul>
         </div>
       </div>
     </nav>
     
     <h1>Welcome to Application</h1>

     
        </div>
         );
}

export default ApplicationManager;
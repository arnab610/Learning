import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import AdminService from '../services/Service';
import { useHistory } from "react-router-dom";
import dateFormat from 'dateformat';

const Cart = () => {
    const [cart, setCart] = useState([]);
    const [userid, setuserId] = useState(-1);
    const init = () => {
        AdminService.getAllCarts()
          .then(response => {
            console.log('Printing Movies data', response.data);
            setCart(response.data);
          })
          .catch(error => {
            console.log('Something went wrong', error);
          }) 
          setuserId(sessionStorage.getItem('id'));
      }
    
      useEffect(() => {
        init();
      }, []);

      const handleDelete=(id)=>{
        AdminService.removeCart(id)
        .then(response => {
          console.log('movie deleted successfully', response.data);
          
         
          init();
        })
        .catch(error => {
          console.log('Something went wrong', error);
        })
        
      }
    return (
        <div className="container">
          <Link to="/user">Back to Home</Link>
            <div className="row">
            {cart.filter((n) => {
                if(userid == "") {
                    return n;
                } else if(n.userId == userid) {
                    return n;
                }
            }).map((m, key) => {
                return (
                (  m.price === 0 && m.price === 0 && m.price === 0)? null : 
                (<div className="col-lg-6 mb-4">
				<div className="card">
					<img className="card-img-top " style={{width: "538px", height: "400px"}} src={m.img} alt=""/>

					<div className="card-body">
						<h5 className="card-title">{m.movieName}</h5>
						<p className="card-text">{m.price}</p>
                        <p className="card-text">{m.multiplex}</p>
                        <p className="card-text">{dateFormat(m.dt, 'mm/dd/yyyy')}</p>
                        <p className="card-text"><b>DISCOUNT : </b>{m.discount} %</p>
          
					</div>
				</div>
			</div>))
})}
            </div>
        </div>
      );
}

export default Cart;
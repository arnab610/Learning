import httpClient from "../http-common";

const getAll = () => {
    return httpClient.get('/admins');
}

const create = data => {
    return httpClient.post("/admins", data);
}

const get = id => {
    return httpClient.get(`/admins/${id}`);
}

const update = data => {
    return httpClient.put('/admins', data);
}

const remove = id => {
    return httpClient.delete(`/admins/${id}`);
}
const getAllMovies = () => {
    return httpClient.get('/movies');
}

const createMovie = data => {
    return httpClient.post("/movie", data);
}

const getMovie = id => {
    return httpClient.get(`/movie/${id}`);
}

const updateMovie = data => {
    return httpClient.put('/movies', data);
}

const removeMovie = id => {
    return httpClient.delete(`/movies/${id}`);
}

const getAllCarts = () => {
    return httpClient.get('/carts');
}

const createCart = data => {
    return httpClient.post("/cart", data);
}

const getCart = id => {
    return httpClient.get(`/cart/${id}`);
}

const updateCart = data => {
    return httpClient.put('/carts', data);
}

const removeCart = id => {
    return httpClient.delete(`/carts/${id}`);
}
export default { getAll, create, get, update, remove, getAllMovies, createMovie, getMovie, updateMovie, removeMovie, getAllCarts, getCart, createCart, removeCart, updateCart };
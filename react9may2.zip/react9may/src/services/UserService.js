import httpClient from "../http-common";

const getAll = () => {
    return httpClient.get('/users');
}

const create = data => {
    return httpClient.post("/user", data);
}

const get = id => {
    return httpClient.get(`/user/${id}`);
}

const update = data => {
    return httpClient.put('/users', data);
}


export default {create, getAll, get, update}
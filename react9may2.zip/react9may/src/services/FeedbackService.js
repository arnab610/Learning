import httpClient from "../http-common";

const getAll = () => {
    return httpClient.get('/feedbacks');
}

const create = data => {
    return httpClient.post("/feedback", data);
}

const get = id => {
    return httpClient.get(`/feedback/${id}`);
}

const update = data => {
    return httpClient.put('/feedbacks', data);
}


export default {create, getAll, get, update}
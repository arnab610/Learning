import httpClient from "../http-common";

const getAll = () => {
    return httpClient.get('/adminfeedbacks');
}

const create = data => {
    return httpClient.post("/adminfeedback", data);
}

const get = id => {
    return httpClient.get(`/adminfeedback/${id}`);
}




export default {create, getAll, get}
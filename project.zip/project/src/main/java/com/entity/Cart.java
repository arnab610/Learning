package com.entity;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "cart")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Cart {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String movieName;
	private long userId;
	private double price;
	private Date dt;
	private int noofHeads;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public Date getDt() {
		return dt;
	}
	public void setDt(Date dt) {
		this.dt = dt;
	}
	public int getNoofHeads() {
		return noofHeads;
	}
	public void setNoofHeads(int noofHeads) {
		this.noofHeads = noofHeads;
	}
	public Cart() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Cart(long id, String movieName, long userId, double price, Date dt, int noofHeads) {
		super();
		this.id = id;
		this.movieName = movieName;
		this.userId = userId;
		this.price = price;
		this.dt = dt;
		this.noofHeads = noofHeads;
	}
	@Override
	public String toString() {
		return "Cart [id=" + id + ", movieName=" + movieName + ", userId=" + userId + ", price=" + price + ", dt=" + dt
				+ ", noofHeads=" + noofHeads + "]";
	}
	
	
	
}
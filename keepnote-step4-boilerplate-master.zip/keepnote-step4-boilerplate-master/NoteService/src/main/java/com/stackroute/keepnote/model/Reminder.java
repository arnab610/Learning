package com.stackroute.keepnote.model;

import java.util.Date;

public class Reminder {
	
	/*
	 * This class should have six fields
	 * (reminderId,reminderName,reminderDescription,reminderType,
	 * reminderCreatedBy,reminderCreationDate).  This class should also contain the
	 * getters and setters for the fields along with the no-arg , parameterized
	 * constructor and toString method. The value of reminderCreationDate should not
	 * be accepted from the user but should be always initialized with the system
	 * date.
	 */
	
	
	  public String getReminderId() {
	        return null;
	    }

	    public void setReminderId(String reminderId) {
	       
	    }

	    public String getReminderName() {
	        return null;
	    }

	    public void setReminderName(String reminderName) {
	       
	    }

	    public String getReminderDescription() {
	        return null;
	    }

	    public void setReminderDescription(String reminderDescription) {
	        
	    }

	    public String getReminderType() {
	        return null;
	    }

	    public void setReminderType(String reminderType) {
	       
	    }

	    public String getReminderCreatedBy() {
	        return null;
	    }

	    public void setReminderCreatedBy(String reminderCreatedBy) {
	        
	    }

	    public Date getReminderCreationDate() {
	        return null;
	    }

	    public void setReminderCreationDate(Date reminderCreationDate) {
	        
	    }


}

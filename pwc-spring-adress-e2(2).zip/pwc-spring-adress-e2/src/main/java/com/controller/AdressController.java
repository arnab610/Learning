package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Adress;

import com.service.AdressService;



@RestController
//@RequestMapping("/main")
public class AdressController {

	
	@Autowired
	private AdressService service;
	
	@GetMapping("/showall")
	public List<Adress> sayHello() {
		List<Adress> lst = service.loadAll();
		return lst;
	}
	@PostMapping("/addAddress")
	
	public String register(@RequestBody Adress adress) {
		service.addAdr(adress);
		return "Registered";
	}
@DeleteMapping("/deleteAddress/{id}")
	
	public ResponseEntity<String> deleteUser(@PathVariable("id")Integer id) {
		if(service.deleteAdr(id)) {
			return new ResponseEntity<>(
					"Deleted"+id,
					HttpStatus.OK
					);
		}
		return new ResponseEntity<>(
				"Not found and couldnot delete"+id,
				HttpStatus.BAD_REQUEST
				);
		
	}
@GetMapping("/findAddress/{id}")

public ResponseEntity<String> showAddress(@PathVariable("id")Integer id) {
	if(service.findAdr(id)) {
		return new ResponseEntity<>(
				"found"+id,
				HttpStatus.OK
				);
	}
	return new ResponseEntity<>(
			"Not found"+id,
			HttpStatus.BAD_REQUEST
			);
	
}


@PutMapping("/updateAddress/{id}")
public ResponseEntity<String> updateUser(@RequestBody Adress adress,@PathVariable("id")int id ) {
if (service.updateAdr(adress, id)) 
{
	return new ResponseEntity<>(
			"found and updates"+id,
			HttpStatus.OK
			);
}
return new ResponseEntity<>(
		"Not found"+id,
		HttpStatus.BAD_REQUEST
		);



}
}

package com.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.model.Adress;


@Repository
public interface AdressDao  extends CrudRepository<Adress ,Integer>  {

}

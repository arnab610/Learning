package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="spring_address")

public class Adress {
	@Id
	@GeneratedValue
private int addId;
private String cityName;
private String state;
private int pin;
public Adress(int addId, String cityName, String state, int pin) {
	super();
	this.addId = addId;
	this.cityName = cityName;
	this.state = state;
	this.pin = pin;
}
public Adress() {
	super();
	// TODO Auto-generated constructor stub
}
public int getAddId() {
	return addId;
}
public void setAddId(int addId) {
	this.addId = addId;
}
public String getCityName() {
	return cityName;
}
public void setCityName(String cityName) {
	this.cityName = cityName;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public int getPin() {
	return pin;
}
public void setPin(int pin) {
	this.pin = pin;
}
@Override
public String toString() {
	return "Adress [addId=" + addId + ", cityName=" + cityName + ", state=" + state + ", pin=" + pin + "]";
}

}

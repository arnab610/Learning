package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.AdressDao;
import com.model.Adress;



@Service
public class AdressService {
	@Autowired
	private AdressDao ad;
	ArrayList <Adress> lst=new ArrayList<Adress>();
	
	public void addAdr(Adress adress) {
		
		ad.save(adress);
		System.out.println(lst);
	}
	
	public List<Adress> loadAll() {
		List<Adress> lst = (List<Adress>)ad.findAll();
		return lst;
		
	}
	public boolean findAdr(Integer id) {
		Optional opt = ad.findById(id);
		if(opt.isPresent()) {
			return true;
		}
		
		return false;
		
		
	}
	public boolean deleteAdr(Integer id) {
		Optional opt = ad.findById(id);
		if(opt.isPresent()) {
			ad.deleteById(id);
			return true;
		}
		return false;
		
		
	}
	
public boolean updateAdr(Adress adress,int id) {
	
		Optional opt = ad.findById(id);
		if(opt.isPresent()) {
			ad.deleteById(id);
			ad.save(adress);
			return true;
		
		
		
	}
			return false;
		
		

}
}

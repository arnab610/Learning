package com.example.pwcspringadresse2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PwcSpringAdressE2ApplicationTests {

	@Test
	void contextLoads() {
	}

}

/**
 * 
 */
package client;


public class Second {


	public void invoke() {
		 System.out.println("Done");
		
	}

}

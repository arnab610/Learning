package com.homeward.service;

public interface Color {
String getColor();
}

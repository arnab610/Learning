
package com.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.UnaryOperator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;



@Service
public class AppService {
	@Autowired
	RestTemplate restTemplate;
	
	@Bean
	@LoadBalanced
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}
	
	public String callApp() {
		String response=restTemplate.exchange("http://emp-service/loademp", 
				HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {}).getBody();
		return response;
	}
	public String callAppWithPara(String loc) {
	//	String response=restTemplate.exchange("http://emp-service/loademp/{loc}", 
		String response=restTemplate.exchange("http://localhost:8050/myemp/loademp/{loc}", 
				HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {},loc).getBody();
		return response;
	}
	
	
	public String callDepWithPara(String project) {
		String response=restTemplate.exchange("http://dep-service/loaddept/{project}", 
				HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {},project).getBody();
		return response;
	}
	public String callDept() {
		String response=restTemplate.exchange("http://dep-service/loaddept", 
				HttpMethod.GET,
				null,
				new ParameterizedTypeReference<String>() {}).getBody();
		return response;
	}
	
	
}


    

function validateform(){  
   
    var name=document.myform.name.value;  
    var password=document.myform.password.value;  
    var email=document.myform.email.value;  
    var city=document.myform.city.value;  


    if (name==null || name==""){  
      alert("Name can't be blank");  
      return false;  
    }else if(password==null || password==""){  
      alert("Password can't be blank"); 
      return false;  
      }  
      else if(email==null || email==""){  
        alert("Email can't be blank"); 
        return false;  
      }
      else if(city==null || city==""){  
        alert("city can't be blank"); 
        return false; 
      }
      show(name, password,email,city); 
    
    }

    function show(name, password, email,city){
        var d = document.getElementById("as");
        d.innerHTML=name+ password+email+city;
    }

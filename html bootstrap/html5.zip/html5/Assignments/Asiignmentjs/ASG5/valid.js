fnum = Math.ceil(-12.5111); snum = Math.floor(-12.5111); tnum = Math.round(-12.5111);
console.log(fnum)
console.log(snum)
console.log(tnum)

d=new Date();
year=d.getFullYear();
month=d.getMonth();
day=d.getDay();
console.log(day+"-"+month+"-"+year)
s= "Arnab"
for(i=0;i<s.length;i++){
    console.log(s.charCodeAt(i))
}

var arr =new Array(1,2,55,66,33,22,1);
console.log(arr.reverse())
small=arr[0]
for(i=0;i<arr.length;i++){
    if(arr[i]<small){
        small=arr[i]
    }
    console.log("small"+ small)
}
    

var w = "js is very easy to understangd"
w1 = w.split(" ")
console.log(w1.sort())
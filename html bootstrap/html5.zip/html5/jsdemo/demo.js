console.log("Welcome to js")
var users=[]
var allusers="<hr/>"
function addUser(){
   
var data=document.getElementById("uname").value
users.push(data)
console.log(users)
for(var a=0;a<users.length;a++){
    allusers+= users[a]+"<br/>"
    console.log(allusers)
}
document.getElementById("show").innerHTML=users+"<br"
}
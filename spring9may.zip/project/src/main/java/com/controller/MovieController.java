package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Movie;
import com.repository.MovieRepository;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin("*")
public class MovieController {
	@Autowired
	private MovieRepository movieRepository;
	
	@PostMapping("/movie")
	public Movie saveUser(@RequestBody Movie movie) {
		return movieRepository.save(movie);
	}
	
	@GetMapping("/movies")
	public List<Movie> getAllUser() {
		return movieRepository.findAll();
	}
	
	@GetMapping("/movie/{id}")
	public Movie getUserById(@PathVariable Long id) {
		return movieRepository.findById(id).get();
	}
	

	@PutMapping("/movies")
	public Movie updateEmployee(@RequestBody Movie movie) {
		return movieRepository.save(movie);
	}
	
	@DeleteMapping("/movies/{id}")
	public ResponseEntity<HttpStatus> deleteUserById(@PathVariable Long id){
		movieRepository.deleteById(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
}

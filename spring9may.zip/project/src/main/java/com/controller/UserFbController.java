package com.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Admin;

import com.entity.Movie;
import com.entity.UserFeedback;
import com.exception.AdminAlreadyExistsException;
import com.exception.AdminNotFoundException;

import com.repository.AdminRepository;
import com.repository.UserFbRepository;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin("*")
public class UserFbController {
	@Autowired
	private UserFbRepository ufr;
	
	@PostMapping("/feedback")
	public UserFeedback saveUser(@RequestBody UserFeedback user) {
		return ufr.save(user);
	}
	
	@GetMapping("/feedbacks")
	public List<UserFeedback > getAllUser() {
		return ufr.findAll();
	}
	
	@GetMapping("/feedback/{id}")
	public UserFeedback  getUserById(@PathVariable Long id) {
		return ufr.findById(id).get();
	}
	@PutMapping("/feedbacks")
	public UserFeedback updatefeedback(@RequestBody UserFeedback user) {
		return ufr.save(user);
	}

}
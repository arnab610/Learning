package com.entity;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "adminfeedback")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class AdminFeedback {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String adminName;
	private String feedback;
	public AdminFeedback(long id, String adminName, String feedback) {
		super();
		this.id = id;
		this.adminName = adminName;
		this.feedback = feedback;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	@Override
	public String toString() {
		return "AdminFeedback [id=" + id + ", adminName=" + adminName + ", feedback=" + feedback + "]";
	}
	public AdminFeedback() {
		super();
		// TODO Auto-generated constructor stub
	}
}
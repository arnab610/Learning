package com.entity;

import java.sql.Time;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "movie")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Movie {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String movName;
	private String description;
	private String img;
	private String multiplex;
	private Date date;
	private Time time;
	private int silverSeat;
	private int goldSeat;
	private int platinumSeat;
	private int discount;
	private double price;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getMovName() {
		return movName;
	}
	public void setMovName(String movName) {
		this.movName = movName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getMultiplex() {
		return multiplex;
	}
	public void setMultiplex(String multiplex) {
		this.multiplex = multiplex;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Time getTime() {
		return time;
	}
	public void setTime(Time time) {
		this.time = time;
	}
	public int getSilverSeat() {
		return silverSeat;
	}
	public void setSilverSeat(int silverSeat) {
		this.silverSeat = silverSeat;
	}
	public int getGoldSeat() {
		return goldSeat;
	}
	public void setGoldSeat(int goldSeat) {
		this.goldSeat = goldSeat;
	}
	public int getPlatinumSeat() {
		return platinumSeat;
	}
	public void setPlatinumSeat(int platinumSeat) {
		this.platinumSeat = platinumSeat;
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Movie [id=" + id + ", movName=" + movName + ", description=" + description + ", img=" + img
				+ ", multiplex=" + multiplex + ", date=" + date + ", time=" + time + ", silverSeat=" + silverSeat
				+ ", goldSeat=" + goldSeat + ", platinumSeat=" + platinumSeat + ", discount=" + discount + ", price="
				+ price + "]";
	}
	public Movie(long id, String movName, String description, String img, String multiplex, Date date, Time time,
			int silverSeat, int goldSeat, int platinumSeat, int discount, double price) {
		super();
		this.id = id;
		this.movName = movName;
		this.description = description;
		this.img = img;
		this.multiplex = multiplex;
		this.date = date;
		this.time = time;
		this.silverSeat = silverSeat;
		this.goldSeat = goldSeat;
		this.platinumSeat = platinumSeat;
		this.discount = discount;
		this.price = price;
	}
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
